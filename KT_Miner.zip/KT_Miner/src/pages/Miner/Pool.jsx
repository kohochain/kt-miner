import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import checkValue from "../../utils/checkValue";

class Pool extends Component {

    constructor(props){
        super(props);
        this.state = {
            level:0,
            memberInfoList:[]
        }
    }

    componentDidMount(){

        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerShareGuarantee({address:address}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    renderCard(){

        const {chainCount, shareRate, nextLevelMdc, nextLevelIcs, guaranteeMdc, guaranteeIcs} = this.state;


        return (
            <div className={'flex-display-col'} style={{backgroundColor:"#F4FAF9", paddingBottom:"6.67vw"}}>
                <div className={'miner-power-bg'} style={{marginTop:"5.33vw"}}>
                    <div style={{paddingLeft:"5.33vw", paddingRight:"4.4vw"}}>
                        <div className={'miner-power-bg-row flex-between'}>
                            <div className={'miner-p5'}>当前共享矿池系数</div>
                            <div className={'miner-p6'}>
                                {this.getRate(shareRate)}
                            </div>
                        </div>
                        <div className={'miner-power-bg-row flex-between'}>
                            <div className={'miner-p5'}>当前有效行业链数目</div>
                            <div className={'miner-p6'}>
                                {this.getGuarantee(chainCount)}
                            </div>
                        </div>
                    </div>
                    <div className={'miner-power-bg-line'}/>
                    <div style={{paddingLeft:"5.33vw", paddingRight:"4.4vw", paddingBottom:"5.33vw"}}>
                        <div className={'miner-p5'} style={{marginTop:"5.33vw"}}>完成任一条件，获得共享矿池算力</div>
                        <div className={'miner-power-bg-row flex-between'}>
                            <div className={'flex-display'}>
                                <div className={'miner-p5'}>1.MDC抵押数量≥{this.getGuarantee(nextLevelMdc)}</div>
                                {(guaranteeMdc >= nextLevelMdc) ? <img src={require('../../images/miner/done.png')} alt="" style={{width:"3.47vw", height:"3.47vw", marginLeft:"2.67vw"}}/> : null}
                            </div>
                            <div className={'miner-p6'}>
                                {this.getGuarantee(guaranteeMdc)}/{this.getGuarantee(nextLevelMdc)}
                            </div>
                        </div>
                        <div className={'miner-power-bg-row flex-between'}>
                            <div className={'flex-display'}>
                                <div className={'miner-p5'}>2.ICS抵押数量≥{this.getGuarantee(nextLevelIcs)}</div>
                                {guaranteeIcs >= nextLevelIcs ? <img src={require('../../images/miner/done.png')} alt="" style={{width:"3.47vw", height:"3.47vw", marginLeft:"2.67vw"}}/> : null}
                            </div>
                            <div className={'miner-p6'}>
                                {this.getGuarantee(guaranteeIcs)}/{this.getGuarantee(nextLevelIcs)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    renderBottom(){

        const list = [1,2,3,4,5,6,7];

        return (
            <div className={'flex-display-col'}>
                <div className={"miner-card"}>
                    <div className={'flex-display-col'} style={{padding:"5.33vw"}}>
                        <div className={"miner-card-header-p"}>
                            共享矿池算力说明
                        </div>
                        <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"4vw"}}>
                            用户可通过抵押规定数量的MDC或ICS获得共享矿池算力。
                        </div>
                        <div className={'miner-p8'} style={{lineHeight:"7.47vw"}}>
                            1.如何抵押MDC：用户可以前往MagicData Pro，在“挖矿”页面授权登录后，选择“抵押得算力”进行MDC的抵押；
                        </div>
                        <div className={'miner-p8'} style={{lineHeight:"7.47vw"}}>
                            2.如何抵押ICS：用户可以前往MagicData Pro，在“应用”页面，搜索“ICS”DApp，点击进入应用进行ICS的抵押。
                        </div>
                        <div className={'miner-p8'} style={{lineHeight:"7.47vw"}}>
                            3.算力发放规则：用户可获得的共享矿池算力=共享矿池系数*CNC静态算力*共享矿池系数加成。
                            共享矿池系数：抵押规定数量的MD或ICS可获得对应的共享矿池系数，具体见下方表格：
                        </div>
                        <div style={{width:"78.67vw", borderWidth:".27vw", borderColor:"#113634", marginTop:"5.33vw"}}>
                            <div className={'flex-between'}>
                                <div className={'flex-center'} style={{backgroundColor: "#2DBBAF", width:"60%", height:"10.67vw"}}>
                                    <div className={'miner-p6'}>抵押数量</div>
                                </div>
                                <div className={'flex-center'} style={{backgroundColor: "#2DBBAF", width:"40%", height:"10.67vw"}}>
                                    <div className={'miner-p6'}>共享矿池系数</div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <div className={'flex-center miner-pool-row-left'}>
                                    <div className={'miner-p1'}>400 MDC或400 ICS</div>
                                </div>
                                <div className={'flex-center miner-pool-row-right'}>
                                    <div className={'miner-p1'}>20%</div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <div className={'flex-center miner-pool-row-left'}>
                                    <div className={'miner-p1'}>800 MDC或800 ICS</div>
                                </div>
                                <div className={'flex-center miner-pool-row-right'}>
                                    <div className={'miner-p1'}>40%</div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <div className={'flex-center miner-pool-row-left'}>
                                    <div className={'miner-p1'}>1200 MDC或1200 ICS</div>
                                </div>
                                <div className={'flex-center miner-pool-row-right'}>
                                    <div className={'miner-p1'}>60%</div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <div className={'flex-center miner-pool-row-left'}>
                                    <div className={'miner-p1'}>1600 MDC或1600 ICS</div>
                                </div>
                                <div className={'flex-center miner-pool-row-right'}>
                                    <div className={'miner-p1'}>80%</div>
                                </div>
                            </div>
                            <div className={'flex-between'}>
                                <div className={'flex-center miner-pool-row-left'}>
                                    <div className={'miner-p1'}>2000 MDC或2000 ICS</div>
                                </div>
                                <div className={'flex-center miner-pool-row-right'}>
                                    <div className={'miner-p1'}>100%</div>
                                </div>
                            </div>
                        </div>
                        <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"4vw"}}>
                            共享矿池系数加成：ICS生态今后将逐步开放更多的行业链，共享矿池系数加成取决于当前地址的有效行业链数目，有效行业链：在该条行业链抵押规定币种数量≥100的视为有效行业链，具体见下方表格。
                        </div>
                        <div style={{width:"78.67vw", borderWidth:".27vw", borderColor:"#113634", marginTop:"5.33vw"}}>
                            <div className={'flex-between'}>
                                <div className={'flex-center'} style={{backgroundColor: "#2DBBAF", width:"60%", height:"10.67vw"}}>
                                    <div className={'miner-p6'}>单个地址的有效行业链数目</div>
                                </div>
                                <div className={'flex-center'} style={{backgroundColor: "#2DBBAF", width:"40%", height:"10.67vw"}}>
                                    <div className={'miner-p6'}>共享矿池系数加成</div>
                                </div>
                            </div>
                            {list.map((item, index)=>{
                                return (
                                    <div key={index} className={'flex-between'}>
                                        <div className={'flex-center miner-pool-row-left'}>
                                            <div className={'miner-p1'}>{item}</div>
                                        </div>
                                        <div className={'flex-center miner-pool-row-right'}>
                                            <div className={'miner-p1'}>{item}</div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    render() {

        const {level, memberInfoList, guaranteeLevel} = this.state;

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#F4FAF9"}}>
                <div className={"flex-start"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>共享矿池算力</div>
                </div>
                {this.renderCard()}
                {this.renderBottom()}
            </div>
        );
    }
}

export default connect(Pool);
