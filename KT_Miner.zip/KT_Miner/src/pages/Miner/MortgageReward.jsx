import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import checkValue from "../../utils/checkValue";
import ToastModal from "./Modal/ToastModal";

const rows = ["CNC抵押挖矿分为12年，24个周期，每周期为6个月，此阶段将产出剩余全部的1.89亿枚CNC。", "第一周期内每月产出剩余总量（1.89亿）的1%；", "第二周期内每月产出剩余总量的1.1%；",
"第三周期内每月产出剩余总量）的1.2%；", "…", "第X周期内每月产出剩余总量）的（1+0.1X）%；以此类推，最后一周期将平均地挖完2.1亿。", "CNC每日抵押挖矿产量依照固定规则由智能合约自动产出，挖矿收益计算公式如下：",
"全网用户每日可挖得CNC总量 = 当日CNC产量 * 当日结束时全网CNC抵押量/当日结束时全网CNC流通量 当日结束时全网CNC流通量=发行量-销毁量", "每日产出但用户未挖得的币将直接进行销毁，用户每日参与抵押挖矿获得的收益和用户的有效算力息息相关。",
"用户每日抵押挖矿收益 = 当日全网用户可挖得CNC总量*用户个人有效算力/全网有效算力", "有效算力 = 静态算力*（1+时间系数加成）+团队激励算力+全球分红算力"];

class MortgageReward extends Component {

    constructor(props){
        super(props);
        this.state = {
            list:[]
        }
    }

    componentDidMount(){
        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerRewardPipeline({address:address, pageSize:50}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState({list:res.content.list});
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    getValue(value, number, mode)
    {
        return checkValue(value, number, mode ? 0 : mode);
    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    renderList(){
        return (
            <div className={'flex-display-col'}>
                {this.state.list.map((item, index)=>{
                    return (
                        <div key={index} className={'miner-card'} style={{marginTop:"5.33vw"}}>
                            <div style={{padding:"0 4vw 5.33vw 4vw"}}>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p2"}>
                                        {moment(item.createTime).format('YYYY-MM-DD')}
                                    </div>
                                    <div className={"miner-p2"}>
                                        {item.level ? (item.level + "星会员"):"普通会员"}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        抵押收益
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getValue(item.reward)} CNC
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        有效算力
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getGuarantee(item.effectiveGuarantee)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        静态算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.frozenGuarantee)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        时间系数加成比例
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getRate(item.dayCountRate)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        团队激励算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.groupGuarantee)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        全球分红算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.globalGuarantee)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        学习算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.otherGuarantee.activityLearn)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        共享矿池算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.shareGuarantee)}
                                    </div>
                                </div>
                                {item.freeGuarantee ? <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        系统赠送算力
                                    </div>
                                    <div className={"miner-p1"}>
                                        {this.getGuarantee(item.freeGuarantee)}
                                    </div>
                                </div> : null}
                            </div>
                        </div>
                    )
                })}
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                <img style={{width:"41.2vw", height:"25.87vw"}} src={require('../../images/resonance/empty1.png')} />
                <div style={{color:"#8E9594", fontSize:"3.47vw", lineHeight:"5.33vw"}}>暂无记录</div>
            </div>
        )
    }

    render() {

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#F4FAF9"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>抵押收益详情</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>收益说明</div>
                </div>
                <ToastModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} title={"收益说明"}
                            rows={rows}/>
                {this.state.list.length ? this.renderList():this.renderEmpty()}
                {/*{this.renderEmpty()}*/}
            </div>
        );
    }
}

export default connect(MortgageReward);
