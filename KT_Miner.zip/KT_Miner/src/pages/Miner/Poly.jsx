import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import checkValue from "../../utils/checkValue";
import ToastModal from "./Modal/ToastModal";
import BigNumber from "bignumber.js";
import FreezeModal from "../Kt/Modal/FreezeModal";
import {getCNCContract, getMiningContract, signTimestamp} from "../../utils/mdc";
import {extensionErr} from "../../lib";
import EditModal from "../Kt/Modal/EditModal";

const imgs = {"done":require('../../images/kt/done.png')};

const rows = ["在抵押KT的同时，用户可以按照规定的比例同时进行KHC的质押获得KHC聚合算力加成。当日抵押次日0点结算时候即可获得算力加成。", "（1）两种质押倍数供用户选择：质押5倍KT数量的KHC、质押10倍KT数量的KHC，质押5倍可以获得10%的算力加成，质押10倍可以获得15%的算力加成。",
 "（2）抵押的KHC可以解押，解押时全额解押，解押规则为T+3。", "（3）质押5倍期间可以通过再次质押享受10倍质押的加成算力：二次质押的数量=10倍的数量-5倍的数量；质押10倍期间也可以选择降至5倍。", "（4）若用户抵押中的KT数量发生变化，系统将根据用户最高可获得的算力加成比例进行算力加成比例的发放。", "在抵押KT的同时，用户可以按照规定的比例同时进行KHC的质押获得KHC聚合算力加成。当日抵押次日0点结算时候即可获得算力加成。",
"每日23：55至次日00：05为系统结算时间，期间将暂停KT的抵押、解押KHC的质押以及奖励的领取，请您在非结算时间进行操作。"];

class Poly extends Component {

    constructor(props){
        super(props);
        this.state = {
            level:0,
            list:[],
            khtRateList:[[5, 0.1], [10, 0.15]],
            khtRate:0,
            khtFrozen:0,
            tab:0,
            tab2:0,
            frozen:0,
            editRate:0,
            unfreezeTimeLabel:"-",

        }
    }

    componentDidMount(){

        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);
        if(address){
            net.getMinerAddressInfo({address:address}).then(res => {
                Toast.hide();
                if(res.response_code === '00')
                {
                    this.setState(res.content);
                    this.setState({editRate:res.content.khtRate});
                    this.timer = setInterval(() => {
                        this.openTimes();
                    }, 1000);
                }
                else {
                    Toast.fail(res.response_msg);
                }
            });

            net.getMinerGuaranteePipelineKht({address:address, pageSize:50}).then(res => {
                if(res.response_code === '00')
                {
                    this.setState({list:res.content.list});
                }
                else {
                    Toast.fail(res.response_msg);
                }
            });

            this.timer2 = setInterval(() => {
                net.getMinerAddressInfo({address:address}).then(res => {
                    if (res.response_code === '00') {
                        this.setState(res.content);
                    } else {
                        Toast.fail(res.response_msg);
                    }
                });
                net.getMinerGuaranteePipelineKht({address:address, pageSize:50}).then(res => {
                    if(res.response_code === '00')
                    {
                        this.setState({list:res.content.list});
                    }
                    else {
                        Toast.fail(res.response_msg);
                    }
                });
            }, 5000);
        }
    }

    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
        if (this.timer2) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    async setKHTRate(){

        Toast.loading('提交中', 0);

        const params = await signTimestamp();

        let data = this.getEditRate();

        params.rate = data.rate;

        net.postMinerKHTRate(params).then(res => {
            if (res.response_code === '00') {
                Toast.success("已修改成功");
            } else {
                Toast.fail(res.response_msg);
            }
        });
    }

    openTimes(){

        const date = this.state.khtUnfreezeTime;

        if(date === undefined || date === null)
        {
            this.setState({unfreezeTimeLabel:"-"});
            return;
        }

        let date3 = (date - moment().valueOf())/1000;   //时间差的毫秒数

        if(date3 < 0)
        {
            this.setState({unfreezeTimeLabel:"-"});
            clearTimeout(this.timer) && (this.timer = null);
            return;
        }

        let leave1= date3 %(24*3600);    //计算天数后剩余的毫秒数
        let hours= Math.floor(date3/(3600));
        //计算相差分钟数
        let leave2 = leave1 % (3600) ;       //计算小时数后剩余的毫秒数
        let minutes = Math.floor(leave2/(60));
        //计算相差秒数
        let leave3 = leave2 % (60) ;     //计算分钟数后剩余的毫秒数
        let seconds = Math.round(leave3);

        let label = (hours < 10 ? ("0" + hours) : hours) + ":" +  (minutes < 10 ? ("0" + minutes) : minutes) + ":" +  (seconds < 10 ? ("0" + seconds) : seconds);

        this.setState({unfreezeTimeLabel:label});
    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    getValue(value, number, mode)
    {
        return checkValue(value, number, mode ? 0 : mode);
    }

    getKhtRate(){
        const {khtRate, khtRateList} = this.state;

        if(khtRate === 0)
        {
            return 0;
        }

        let result = 0;

        khtRateList.map((item, index)=>{

            if (Number(item[1]) === Number(khtRate))
            {
                result = item[0];
            }
        });

        return result;
    }

    getEditRate(){
        const {khtRate, khtRateList, khtFrozen, frozen} = this.state;

        if(khtRate === 0)
        {
            return 0;
        }

        let result = [0,0];

        khtRateList.map((item, index)=>{

            if (Number(item[1]) !== Number(khtRate))
            {
                result = item;
            }
        });

        return {rate:result[1], value:result[1] > khtRate ? (result[0] * frozen - khtFrozen) : 0, num:result[0]};
    }

    getKHTValue(){

        const {frozen, khtRateList, tab2, khtFrozen} = this.state;

        if(frozen === 0)
        {
            return 0;
        }

        return new BigNumber(frozen).times(khtRateList[tab2][0]).minus(khtFrozen).toNumber();
    }

    async getContract(){
        if(!this.contract){
            this.contract = await getMiningContract();
        }

        return this.contract;
    }

    async miningCheck(){
        const {kht} = this.props.redux.balance;
        if(kht <= this.getKHTValue())
        {
            Toast.fail('KHC余额不足');
            return;
        }

        Toast.loading('提交中', 0);

        this.setState({rateFlag:false}); //判断是否是修改倍率

        const contract = await this.getContract();
        contract.freeze(this.getKHTValue(), 1).send({callValue:window.KHCExtension.toSun(this.getKHTValue())}).then(res => {
            this.checkHash(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async freeze(){
        const {kht} = this.props.redux.balance;
        if(kht <= this.getKHTValue())
        {
            Toast.fail('KHC余额不足');
            return;
        }

        Toast.loading('提交中', 0);

        this.setState({rateFlag:true}); //判断是否是修改倍率

        let data = this.getEditRate();

        const contract = await this.getContract();
        contract.freeze(data.value, 1).send({callValue:window.KHCExtension.toSun(data.value)}).then(res => {
            this.checkHash(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async unfreeze(){
        const {kht} = this.props.redux.balance;
        if(kht === 0)
        {
            Toast.fail('KHC余额为0，不足支付交易手续费');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await this.getContract();

        // let fee = await contract.fee().call();

        // fee = window.KHCExtension.toDecimal(fee);

        contract.unfreeze(1).send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    checkHash(hash) {
        window.KHCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret2 ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                if(this.state.rateFlag)
                {
                    this.setKHTRate();
                }
                else {
                    Toast.hide();
                    Toast.success("操作成功，请稍后查看");
                }
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    renderCard(){

        const {frozen, khtFrozen, tab, khtRate} = this.state;

        let render;
        let type = 0;

        if(tab === 1)
        {
            render = this.renderUnfreeze();
        } else {
            if(khtRate === 0)
            {
                render = this.renderStep1();
            }
            else if(frozen === 0)
            {
                render = this.renderStep2();
            }
            else {
                render = this.renderStep3();
            }
        }

        return (
            <div style={{width:"100vw"}}>
                {!khtRate ? <div style={{color:"#EE7E4D", fontSize:"3.2vw", padding:"5.33vw", paddingBottom:"0", lineHeight:"5.6vw"}}>
                    {!KHCFrozen ? "您当前没有抵押中的KT，您可以选择解押质押的KHC或进行KT的抵押继续享受KHC聚合算力。" : "您当前所质押的KT数量不足以继续获得KHC聚合算力加成，您可以选择增加质押的KHT或者调整您的质押倍数。"}
                </div> : null}
                <div className={'flex-display'} style={{marginTop:"5.33vw"}}>
                    <div onClick={()=>{this.setState({tab:0})}} className={tab ? 'kt-miner-select-left-unselect':'kt-miner-select-left-select'}>
                        质押
                    </div>
                    <div onClick={()=>{this.setState({tab:1})}} className={tab ? 'kt-miner-select-right-select':'kt-miner-select-right-unselect'}>
                        解押
                    </div>
                </div>
                {render}
            </div>
        )
    }

    renderStep1(){

        const {tab, frozen, khtFrozen, tab2, khtRateList, pause} = this.state;

        let systemTime = false;

        if(Number(moment().format("HH")) === 23 && Number(moment().format("mm")) >= 50)
        {
            systemTime = true;
        }

        if(Number(moment().format("HH")) === 0 && Number(moment().format("mm")) <= 5)
        {
            systemTime = true;
        }

        const ContractPause = pause === 1;

        const disable = !frozen || ContractPause || systemTime;

        return (
            <div className={'kt-miner-card'}>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        抵押中KT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(frozen)} KT
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        可质押KHT的比例
                    </div>
                    <div className={'flex-display'}>
                        <div onClick={()=>{this.setState({tab2:0})}} className={tab2 === 0 ? 'kt-poly-select':'kt-poly-unselect'} style={{marginRight:"2.67vw"}}>
                            质押{khtRateList[0][0]}倍KHT
                        </div>
                        <div onClick={()=>{this.setState({tab2:1})}} className={tab2 === 1 ? 'kt-poly-select':'kt-poly-unselect'}>
                            质押{khtRateList[1][0]}倍KHT
                        </div>
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        需质押KHT的数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getKHTValue()} KHT
                    </div>
                </div>
                <div className={disable ? 'kt-btn-disable':'kt-btn'} onClick={disable ? ()=>{} : ()=>{this.setState({khtFrozenVisible:true})}}>
                    {disable ? (ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间":"请先抵押KT")):"质押"}
                </div>
            </div>
        )
    }

    renderStep2(){

        const {frozen, khtFrozen} = this.state;

        return (
            <div className={'kt-miner-card'}>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        抵押中KT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(frozen)} KT
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        质押中KHT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(khtFrozen)} KHT
                    </div>
                </div>
                <div className={'kt-btn-disable'} onClick={()=>{}}>
                    请先抵押KT
                </div>
            </div>
        )
    }

    renderStep3(){
        const {tab, frozen, khtFrozen, pause, editRate, khtRate} = this.state;

        let systemTime = false;

        if(Number(moment().format("HH")) === 23 && Number(moment().format("mm")) >= 50)
        {
            systemTime = true;
        }

        if(Number(moment().format("HH")) === 0 && Number(moment().format("mm")) <= 5)
        {
            systemTime = true;
        }

        const ContractPause = pause === 1;

        const disable = !frozen || ContractPause || systemTime;

        return (
            <div className={'kt-miner-card'}>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        抵押中KT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(frozen)} KT
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        质押中KHT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(khtFrozen)} KHT
                    </div>
                </div>
                <div className={'flex-end'}>
                    <div onClick={()=>{this.setState({editVisible:true})}} style={{color:"#3726D7", fontSize:"3.73vw"}}>修改质押倍数</div>
                </div>
            </div>
        )
    }

    renderUnfreeze(){
        const {tab, frozen, khtFrozen, pause, khtUnfreezing} = this.state;

        let systemTime = false;

        if(Number(moment().format("HH")) === 23 && Number(moment().format("mm")) >= 50)
        {
            systemTime = true;
        }

        if(Number(moment().format("HH")) === 0 && Number(moment().format("mm")) <= 5)
        {
            systemTime = true;
        }

        const ContractPause = pause === 1;

        const disable = !khtFrozen || ContractPause || systemTime;

        return (
            <div className={'kt-miner-card'}>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        抵押中KHT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(khtFrozen)} KHT
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        解押中KHT数量
                    </div>
                    <div className={'kt-p6'}>
                        {this.getGuarantee(khtUnfreezing)} KHT
                    </div>
                </div>
                <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                    <div className={'kt-p6'}>
                        解押倒计时
                    </div>
                    <div className={'kt-p6'}>
                        {this.state.unfreezeTimeLabel}
                    </div>
                </div>
                <div className={disable ? 'kt-btn-disable':'kt-btn'} onClick={disable ? ()=>{} : ()=>{this.setState({unfreezeVisible:true})}}>
                    {ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间" :(khtFrozen ? "解押":"暂无抵押中KHT"))}
                </div>
            </div>
        )
    }

    getType(type){
        switch (type) {
            case 0:
                return "质押";
            case 1:
                return "解押";
            case 2:
                return "赠送";
        }
    }

    renderBottom(){

        const {list} = this.state;

        return (
            <div className={'flex-display-col'} style={{width:"100vw"}}>
                <div className={'kt-group-card'} style={{marginTop:"5.33vw", marginBottom:"10.67vw"}}>
                    <div className={'flex-display'} style={{marginBottom:"5.33vw"}}>
                        <div className={'kt-p8'}>质押流水</div>
                    </div>
                    <div className={'flex-center'} style={{width:"89.33vw", marginTop:"5.33vw"}}>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>时间</div>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>操作类型</div>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>操作数量</div>
                    </div>
                    <div>
                        {list.map((item, index) => {
                            return (
                                <div key={index} className={'flex-center'} style={{width:"89.33vw", marginTop:"4.93vw"}}>
                                    <div className={'flex-center-col'} style={{width:"33.3%"}}>
                                        <div className={'miner-p8'} style={{lineHeight:"5.86vw", textAlign:"center"}}>
                                            {moment(item.createTime).format('YYYY-MM-DD')}
                                        </div>
                                        <div className={'miner-p8'} style={{lineHeight:"5.86vw", textAlign:"center"}}>
                                            {moment(item.createTime).format('HH:mm:ss')}
                                        </div>
                                    </div>
                                    <div className={'miner-p8'} style={{width:"33.3%", textAlign:"center"}}>{this.getType(item.type)}</div>
                                    <div className={'miner-p8'} style={{width:"33.3%", textAlign:"center"}}>{item.quantity}</div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-display-col'} style={{backgroundColor:"#EEF1FA"}}>
                <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                    <img style={{width:"52.53vw", height:"33.07vw"}} src={require('../../images/kt/empty.png')} />
                    <div style={{color:"#909093", fontSize:"3.47vw", lineHeight:"5.33vw"}}>暂无下级抵押记录</div>
                </div>
            </div>
        )
    }

    render() {

        const {level, list, khtFrozenVisible, khtRate, khtFrozen, editVisible, unfreezeVisible} = this.state;

        return (
            <div className="page miner" style={{backgroundColor:"#EEF1FA"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div className={'miner-p3'} style={{color:"transparent"}}>分红说明</div>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>KHT聚合算力</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>质押说明</div>
                </div>
                <ToastModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} title={"质押说明"}
                            rows={rows}/>
                <FreezeModal visible={khtFrozenVisible} text={"正在进行KHT聚合算力质押。质押为链上交易，需要收取极少的KHT作为合约服务费。"}
                             title={"质押KHT数量"} amount={this.getKHTValue()} unit={'KHT'} onClose={()=>{
                                 this.setState({khtFrozenVisible:false});
                }} commit={()=>{
                    this.setState({khtFrozenVisible:false});
                    this.miningCheck();
                }}/>
                <FreezeModal visible={unfreezeVisible} text={"正在进行聚合质押解押。确认解押后算力加成立即减少且解押的KHT将在T+3日后的24:00:00全额到账！解押为链上交易，需要收取极少的KHT作为合约服务费。"}
                             title={"解押KHT数量"} amount={khtFrozen} unit={'KHT'} onClose={()=>{
                    this.setState({unfreezeVisible:false});
                }} commit={()=>{
                    this.setState({unfreezeVisible:false});
                    this.unfreeze();
                }}/>
                <EditModal visible={editVisible}
                           data={this.getEditRate()}
                           onClose={()=>{this.setState({editVisible:false})}} commit={(flag)=>{
                    this.setState({editVisible:false});
                    if(flag){
                        this.freeze();
                    }
                    else {
                        this.setKHTRate();
                    }
                }} />
                <div className={'miner-power-bg flex-center-col'} style={{height:"18.67vw"}}>
                    <div style={{color:"white", fontSize:"4.27vw", fontWeight:"bold", lineHeight:"6.4vw"}}>
                        当前KHT聚合算力加成：{khtRate ? this.getRate(khtRate):"暂无"}
                    </div>
                    <div style={{color:"white", fontSize:"4.27vw", fontWeight:"bold", lineHeight:"6.4vw"}}>
                        {khtRate ? ("质押倍数:" + this.getKhtRate() + "倍"):(khtFrozen ? "当前抵押KHT数量不足以获得算力加成" : "抵押KHT即可获得KHT聚合算力加成")}
                    </div>
                </div>
                {this.renderCard()}
                {/*{level < 2 ? this.renderEnter() : null}*/}
                {/*{this.renderBottom()}*/}
                {list.length ? this.renderBottom() : null}
            </div>
        );
    }
}

export default connect(Poly);
