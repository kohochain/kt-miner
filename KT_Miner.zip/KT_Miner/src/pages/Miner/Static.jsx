import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import ToastModal from "./Modal/ToastModal";

const rows = ["用户需激活KID并购买方可参与KT算力挖矿。",
    "参与算力挖矿的每个地址，最小抵押数目为100枚KT，用户地址抵押1枚KT即可获得1单位的静态算力。",
    "每日23：55至次日00：05为系统结算时间，期间将暂停KT的抵押、解押KHT的质押以及奖励的领取，请您在非结算时间进行操作。",
    "另，链上交易存在延迟，为保证您抵押操作的顺利进行，建议您不要在每日抵押时间截止前进行激活和抵押，以免造成抵押失败。",
];

class Static extends Component {

    constructor(props){
        super(props);
        this.state = {
            list:[]
        }
    }

    componentDidMount(){
        // this.login();
        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerGuaranteePipeline({address:address, pageSize:50}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState({list:res.content.list});
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    getType(type, refund){
        switch (type) {
            case 0:
                if(refund) return '续押';
                return "抵押";
            case 1:
                return "解押";
            case 2:
                return "系统赠送";
        }
    }

    getOre(type){
        switch (type) {
            case 0:
                return "+";
            case 1:
                return "-";
            case 2:
                return "+";
        }
    }

    renderList(){
        return (
            <div>
                <div className={'flex-display-col'}>
                    <div className={'flex-display'} style={{width:"100vw"}}>
                        <div className={'flex-center'} style={{width:"25%", height:"10.47vw"}}>
                            <div className={"kt-static-p"} style={{textAlign:"center"}}>
                                时间
                            </div>
                        </div>
                        <div className={'flex-center'} style={{width:"15%", height:"10.47vw"}}>
                            <div className={"kt-static-p"} style={{textAlign:"center"}}>
                                类型
                            </div>
                        </div>
                        <div className={'flex-center'} style={{width:"18.75%", height:"10.47vw"}}>
                            <div className={"kt-static-p"} style={{textAlign:"center"}}>
                                操作数量
                            </div>
                        </div>
                        <div className={'flex-center'} style={{width:"18.75%", height:"10.47vw"}}>
                            <div className={"kt-static-p"} style={{textAlign:"center"}}>
                                算力数量
                            </div>
                        </div>
                        <div className={'flex-center'} style={{width:"22.75%", height:"10.47vw"}}>
                            <div className={"kt-static-p"} style={{textAlign:"center"}}>
                                连续抵押天数
                            </div>
                        </div>
                    </div>
                </div>
                {this.state.list.map((item, index)=>{
                    return (
                        <div key={index} className={'flex-display'} style={{width:"100vw", marginBottom:"5.33vw"}}>
                            <div className={'flex-center-col'} style={{width:"25%"}}>
                                <div className={'kt-static-p2'} style={{lineHeight:"5.86vw", textAlign:"center"}}>
                                    {moment(item.createTime).format('YYYY-MM-DD')}
                                </div>
                                <div className={'kt-static-p2'} style={{lineHeight:"5.86vw", textAlign:"center"}}>
                                    {moment(item.createTime).format('HH:mm:ss')}
                                </div>
                            </div>
                            <div className={'flex-center'} style={{width:"15%"}}>
                                <div className={"kt-static-p2"} style={{textAlign:"center"}}>
                                    {this.getType(item.type, item.refund)}
                                </div>
                            </div>
                            <div className={'flex-center'} style={{width:"18.75%"}}>
                                <div className={"kt-static-p2"} style={{textAlign:"center"}}>
                                    {item.quantity}
                                </div>
                            </div>
                            <div className={'flex-center'} style={{width:"18.75%"}}>
                                <div className={"kt-static-p2"} style={{textAlign:"center"}}>
                                    {this.getOre(item.type)}{item.guarantee}
                                </div>
                            </div>
                            <div className={'flex-center'} style={{width:"22.5%"}}>
                                <div className={"kt-static-p2"} style={{textAlign:"center"}}>
                                    {item.type === 0 && item.status === 0 ? item.dayCount : "-"}
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                <img style={{width:"52.53vw", height:"33.07vw"}} src={require('../../images/kt/empty.png')} />
                <div style={{color:"#909093", fontSize:"3.47vw", lineHeight:"5.33vw"}}>暂无记录</div>
            </div>
        )
    }

    render() {

        return (
            <div className="page miner" style={{backgroundColor:"#EEF1FA"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div className={'miner-p3'} style={{color:"transparent"}}>算力说明</div>
                    <div style={{fontSize:"4.53vw", color:"black", fontWeight:"bold"}}>静态算力记录</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>算力说明</div>
                </div>
                <ToastModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} title={"静态算力说明"}
                            rows={rows}/>
                {this.state.list.length ? this.renderList():this.renderEmpty()}
            </div>
        );
    }
}

export default connect(Static);
