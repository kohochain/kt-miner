import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import ToastModal from "./Modal/ToastModal";

const rows = ["每次领取挖矿收益时，本次领取收益总量的10%将根据CNC/USDT在CNC链上交易区的均价折算为USDT，并作为今后生态其他子链的优先认购权，同时该部分收益将进行销毁通缩。"];

class Subscription extends Component {

    constructor(props){
        super(props);
        this.state = {
            list:[],
            total:"-"
        }
    }

    componentDidMount(){
        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerBurnPipeline({address:address, pageSize:50}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    renderList(){
        return (
            <div className={'flex-display-col'} style={{backgroundColor:"#F4FAF9"}}>
                <div className={'miner-subscription-bg flex-center-col'} style={{marginTop:"5.33vw", marginBottom:"5.33vw", }}>
                    <div className={'miner-p1'}>子链认购权</div>
                    <div className={'flex-end-s'} style={{marginTop:"4vw"}}>
                        <div style={{color:"#103533", fontSize:"4.53vw", fontWeight:"bold", marginRight:"2vw"}}>
                            {this.state.total}
                        </div>
                        <div style={{color:"#103533", fontSize:"3.47vw", fontWeight:"bold"}}>
                            USDT
                        </div>
                    </div>
                </div>
                <div style={{backgroundColor:"white"}}>
                    <div className={'flex-display-col'}>
                        <div className={'flex-display'} style={{width:"100vw", backgroundColor:"white"}}>
                            <div className={'flex-center'} style={{width:"50%", height:"10.47vw"}}>
                                <div className={"miner-p1"} style={{textAlign:"center"}}>
                                    时间
                                </div>
                            </div>
                            <div className={'flex-center'} style={{width:"50%", height:"10.47vw"}}>
                                <div className={"miner-p1"} style={{textAlign:"center"}}>
                                    算力数量
                                </div>
                            </div>
                        </div>
                    </div>
                    {this.state.list.map((item, index)=> {
                        return (
                            <div className={'flex-display'} style={{width:"100vw", backgroundColor:"white", marginBottom:"5.33vw"}}>
                                <div className={'flex-center-col'} style={{width:"50%"}}>
                                    <div className={"miner-p8"} style={{textAlign:"center"}}>
                                        {moment(item.createTime).format('YYYY-MM-DD HH:mm:ss')}
                                    </div>
                                </div>
                                <div className={'flex-center'} style={{width:"50%"}}>
                                    <div className={"miner-p8"} style={{textAlign:"center"}}>
                                        {item.quantity} USDT
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                <img style={{width:"41.2vw", height:"25.87vw"}} src={require('../../images/miner/empty.png')} />
                <div style={{color:"#8E9594", fontSize:"3.47vw", lineHeight:"5.33vw"}}>您还没有获得子链认购权哦</div>
                <div style={{color:"#8E9594", fontSize:"3.47vw", lineHeight:"5.33vw"}}>每次领取挖矿收益时均可获得子链认购权</div>
            </div>
        )
    }

    render() {

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#F4FAF9"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>认购权详情</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>规则</div>
                </div>
                <ToastModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} title={"文化链认购权规则"}
                            rows={rows}/>
                {this.state.list.length ? this.renderList():this.renderEmpty()}
            </div>
        );
    }
}

export default connect(Subscription);
