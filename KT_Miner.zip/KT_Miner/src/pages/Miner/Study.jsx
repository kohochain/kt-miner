import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";

class Study extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    componentDidMount(){
        // this.login();
    }



    componentWillUnmount() {

    }

    renderList(){
        return (
            <div>
                <div className={'flex-display-col'}>
                    <div className={'flex-display'} style={{width:"100vw"}}>
                        <div className={'flex-center'} style={{width:"50%", height:"10.47vw"}}>
                            <div className={"miner-p1"} style={{textAlign:"center"}}>
                                时间
                            </div>
                        </div>
                        <div className={'flex-center'} style={{width:"50%", height:"10.47vw"}}>
                            <div className={"miner-p1"} style={{textAlign:"center"}}>
                                算力数量
                            </div>
                        </div>
                    </div>
                </div>
                <div className={'flex-display'} style={{width:"100vw", marginBottom:"5.33vw"}}>
                    <div className={'flex-center-col'} style={{width:"50%"}}>
                        <div className={"miner-p8"} style={{textAlign:"center"}}>
                            {moment().format('YYYY-MM-DD HH:mm:ss')}
                        </div>
                    </div>
                    <div className={'flex-center'} style={{width:"50%"}}>
                        <div className={"miner-p8"} style={{textAlign:"center"}}>
                            +100
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                <img style={{width:"41.2vw", height:"25.87vw"}} src={require('../../images/resonance/empty1.png')} />
                <div style={{color:"#8E9594", fontSize:"3.47vw", lineHeight:"5.33vw"}}>暂无记录</div>
            </div>
        )
    }

    render() {

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#F4FAF9"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>学习算力详情</div>
                    <div className={'miner-p3'}>算力说明</div>
                </div>
                {this.renderList()}
                {/*{this.renderEmpty()}*/}
            </div>
        );
    }
}

export default connect(Study);
