import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import checkValue from "../../utils/checkValue";
import ToastModal from "./Modal/ToastModal";
import PowerRuleModal from "../Kt/Modal/PowerRuleModal";
import addressHide from "../../utils/addressHide";

const imgs = {"done":require('../../images/kt/done.png')};

class Power extends Component {

    constructor(props){
        super(props);
        this.state = {
            level:0,
            memberInfoList:[]
        }
    }

    componentDidMount(){

        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerGlobalInfo({address:address}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    renderCard(){

        const {level, bigMemberFrozen, bigMemberMaxLevel, otherMemberFrozen, otherMemberFrozenNextLevel, sameLevelUserCount, globalRate, globalGuaranteeLimit} = this.state;

        const done1 = (bigMemberFrozen >= otherMemberFrozen/4 && otherMemberFrozen > 0);
        const done2 = otherMemberFrozen >= otherMemberFrozenNextLevel;

        return (
            <div className={'kt-group-card'} style={{padding:0, width:"100vw"}}>
                {level > 0 ? <div className={'miner-power-bg flex-center-col'} style={{height:"18.67vw"}}>
                    <div style={{color:"white", fontSize:"4.27vw", fontWeight:"bold"}}>{level}星会员</div>
                    <div style={{color:"white", fontSize:"3.2vw", marginTop:"3.2vw"}}>加权分红比例：{this.getRate(globalRate)}、全网{level}星会员人数:{sameLevelUserCount}</div>
                </div> : <div className={'miner-power-bg flex-center-col'} style={{height:"18.67vw"}}>
                    <div style={{color:"white", fontSize:"4.27vw", fontWeight:"bold", lineHeight:"6.4vw"}}>
                        升级会员
                    </div>
                    <div style={{color:"white", fontSize:"4.27vw", fontWeight:"bold", lineHeight:"6.4vw"}}>
                        享受全球分红算力
                    </div>
                </div>}
                <div style={{textAlign:"center", marginTop:"5.33vw"}} className={'kt-group-p1'}>完成以下条件，获得更高算力加成（0点更新）</div>
                <div className={'flex-center'} style={{paddingBottom:"5.33vw"}}>
                    <div className={done1 ? 'kt-group-condition1 relative flex-center-col':'kt-group-condition2 relative flex-center-col'} style={{marginRight:"4vw"}}>
                        {done1 ? <img className={'kt-group-done'} src={imgs['done']} /> : null}
                        <div className={'kt-group-p1'}>
                            大区业绩≥小区业绩的1/4
                        </div>
                        <div className={'kt-group-p2'}>
                            {this.getGuarantee(bigMemberFrozen)}/{this.getGuarantee(otherMemberFrozen/4)}
                        </div>
                    </div>
                    <div className={done2 ? 'kt-group-condition1 relative flex-center-col' : 'kt-group-condition2 relative flex-center-col'}>
                        {done2 ? <img className={'kt-group-done'} src={imgs['done']} /> : null}
                        <div className={'kt-group-p1'}>
                            小区抵押数≥{this.getGuarantee(otherMemberFrozenNextLevel)}
                        </div>
                        <div className={'kt-group-p2'}>
                            {this.getGuarantee(otherMemberFrozen)}/{this.getGuarantee(otherMemberFrozenNextLevel)}
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    renderBottom(){

        const {memberInfoList, bigMember, bigMemberMaxLevel, bigMemberFrozen, otherMemberFrozen} = this.state;

        return (
            <div className={'flex-display-col'} style={{width:"100vw"}}>
                <div className={'kt-group-card'} style={{marginTop:"5.33vw"}}>
                    <div className={'flex-display'} style={{marginBottom:"5.33vw"}}>
                        <div className={'kt-p8'}>大区抵押</div>
                        <img onClick={()=>{this.setState({bigVisible:true})}} className={'miner-info'} src={require('../../images/kt/info2.png')} alt='' />
                    </div>
                    <div className={'flex-center'}>
                        <div className={'flex-center-col'} style={{width:"33.3%"}}>
                            <div className={'kt-p9'}>直推用户</div>
                            <div className={'kt-p7'} style={{marginTop:"4.27vw"}}>{addressHide(bigMember)}</div>
                        </div>
                        <div className={'flex-center-col'} style={{width:"33.3%"}}>
                            <div className={'kt-p9'}>社区最高等级</div>
                            <div className={'kt-p7'} style={{marginTop:"4.27vw"}}>{bigMemberMaxLevel > 0 ? (bigMemberMaxLevel + "星会员"):"普通用户"}</div>
                        </div>
                        <div className={'flex-center-col'} style={{width:"33.3%"}}>
                            <div className={'kt-p9'}>大区抵押业绩</div>
                            <div className={'kt-p7'} style={{marginTop:"4.27vw"}}>{bigMemberFrozen}</div>
                        </div>
                    </div>
                </div>
                <div className={'kt-group-card'} style={{marginTop:"5.33vw", marginBottom:"10.67vw"}}>
                    <div className={'flex-display'} style={{marginBottom:"5.33vw"}}>
                        <div className={'kt-p8'}>小区抵押</div>
                        <img onClick={()=>{this.setState({otherVisible:true})}} className={'miner-info'} src={require('../../images/kt/info2.png')} alt='' />
                    </div>
                    <div className={'kt-group-card-gray flex-center-col'} style={{height:"14.13vw"}}>
                        <div className={'kt-p6'}>小区抵押业绩：{otherMemberFrozen}</div>
                    </div>
                    <div className={'flex-center'} style={{width:"89.33vw", marginTop:"5.33vw"}}>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>直推用户</div>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>社区最高等级</div>
                        <div className={'miner-p1'} style={{width:"33.3%", textAlign:"center"}}>社区抵押业绩</div>
                    </div>
                    <div>
                        {memberInfoList.map((item, index) => {
                            return (
                                <div key={index} className={'flex-center'} style={{width:"89.33vw", marginTop:"4.93vw"}}>
                                    <div className={'flex-center'} style={{width:"33.3%"}}>
                                        <div className={'miner-p8'}>{addressHide(item.address)}</div>
                                    </div>
                                    <div className={'miner-p8'} style={{width:"33.3%", textAlign:"center"}}>{item.maxLevel > 0 ? (item.maxLevel + "星会员"):"普通用户"}</div>
                                    <div className={'miner-p8'} style={{width:"33.3%", textAlign:"center"}}>{item.frozen}</div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        )
    }

    renderEmpty(){
        return (
            <div className={'flex-display-col'} style={{backgroundColor:"#EEF1FA"}}>
                <div className={'flex-center-col'} style={{marginTop:"14.8vw"}}>
                    <img style={{width:"52.53vw", height:"33.07vw"}} src={require('../../images/kt/empty.png')} />
                    <div style={{color:"#909093", fontSize:"3.47vw", lineHeight:"5.33vw"}}>暂无下级抵押记录</div>
                </div>
            </div>
        )
    }

    render() {

        const {level, memberInfoList, guaranteeLevel, bigVisible, otherVisible} = this.state;

        return (
            <div className="page miner" style={{backgroundColor:"#EEF1FA"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div className={'miner-p3'} style={{color:"transparent"}}>分红说明</div>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>全球分红算力详情</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>分红说明</div>
                </div>
                <PowerRuleModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} />
                <ToastModal visible={bigVisible} onClose={()=>{this.setState({bigVisible:false})}} title={""}
                            rows={['大区：指下级会员中抵押KT总量最多的一条会员关系']}/>
                <ToastModal visible={otherVisible} onClose={()=>{this.setState({otherVisible:false})}} title={""}
                            rows={['小区：除大区之外的所有下级会员关系']}/>
                {this.renderCard()}
                {/*{level < 2 ? this.renderEnter() : null}*/}
                {/*{this.renderBottom()}*/}
                {memberInfoList.length ? this.renderBottom() : this.renderEmpty()}
            </div>
        );
    }
}

export default connect(Power);
