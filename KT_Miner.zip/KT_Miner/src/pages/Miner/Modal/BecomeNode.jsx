import React, { Component } from "react";
import { Modal, Toast } from "antd-mobile";
// import {approveIcs, getResult, register, activeAccount} from '../../../lib/account';
import CheckBox from "./CheckBox";
import {approveIcs, getResult, register, activeAccount, getIcsFee} from "../../../utils/mdc";
import net from '../../../server';
import {Input} from "../../Swap/components";

class BecomeNode extends Component {
    constructor(props) {
        super(props);

        this.state = {
            checked: true,
            inviteCode: '',
        }

        this.becomeNode = this.becomeNode.bind(this);
    }

    async checkApprove(hash, callback) {
        const result = await getResult(hash);
        console.log(result);

        if (result.ret) {
            if(result.ret && result.ret[0]['contractRet'] === 'SUCCESS'){
                callback()
            } else {
                Toast.fail('帐号激活失败');
            }
        } else {
            setTimeout(() => this.checkApprove(hash, callback), 2000)
        }
    }

    async becomeNode() {
        this.props.onClose();
        const { isRegistered, balance, address, deviceId } = this.props;
        const { checked, inviteCode } = this.state;
        let fee = await getIcsFee();

        fee = window.MDCExtension.toDecimal(fee);
        fee = Number(window.MDCExtension.fromSun(fee));

        console.log('fee', fee);

        if (address) {
            if (balance.mdc === 0) {
                Toast.fail('余额不足，无法调用合约！');
                return;
            }

            Toast.loading('激活中...', 0);
            if (!isRegistered) {
                const res = await net.getPurchaseCheckInviteCode({invitationCode: inviteCode});

                if (res.response_code !== '00') {
                    Toast.fail('无效的邀请码！');
                    return;
                }
            }

            if (isRegistered || checked) {
                if (balance.ics < fee) {
                    Toast.fail('ICS余额不足！');
                    return;
                }

                const preRes = await approveIcs(fee);

                if (preRes) {
                    await this.checkApprove(preRes, async () => {
                        const result = await activeAccount(inviteCode, deviceId);
                        console.log('activeAccount ---> ', result);
                        if (result) {
                            Toast.success('帐号激活申请成功，请稍后查看结果', 2);
                        } else {
                            Toast.fail('帐号激活失败')
                        }
                    })
                } else {
                    Toast.fail('帐号激活失败')
                }
            } else {
                const result = await register(inviteCode);
                console.log('register ---> ', result)
                if (result) {
                    Toast.success('帐号激活申请成功，请稍后查看结果', 2)
                } else {
                    Toast.fail('帐号激活失败')
                }
            }
        } else {
            Toast.fail('帐号激活失败');
        }
    }

    async getFee(){
        if(this.fee === null){
            this.fee = await getIcsFee();
        }

        return this.fee;
    }

    render() {
        const { isRegistered, fee, onClose } = this.props;

        return (
            <Modal
                popup
                visible={this.props.visible}
                animationType="slide-up"
            >
                <div className="miner-modal">
                    <div className={'miner-modal-header flex-between'}>
                        <div onClick={()=>{onClose()}} className={'miner-modal-cancel'}>取消</div>
                        <div className={'miner-modal-title'}>账户激活</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        {isRegistered ? <div>
                                <div style={{color:"#7F8E9A", fontSize:"3.73vw"}}>激活您的账号</div>
                            </div>
                        :   <div>
                                <div className={'common-input-label'}>
                                    您的直推上级的邀请码
                                </div>
                                <Input
                                    width={'81.33vw'}
                                    value={this.state.inviteCode}
                                    onChange={(val) => {
                                        this.setState({ inviteCode:val })
                                    }}
                                />
                                <div className="flex-start">
                                    <CheckBox
                                        checked={this.state.checked}
                                        onChange={v => this.setState({ checked: v })}
                                    />
                                    <div style={{color:"#7F8E9A", fontSize:"3.73vw", marginLeft:"2vw"}}>同时成为正式会员</div>

                                    {/*<span className="m-l-2">同时{fee ? `支付${fee} ICS` : ''}成为正式会员</span>*/}
                                </div>
                            </div>}
                        <div className={'miner-btn'} onClick={this.becomeNode}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}

export default BecomeNode;
