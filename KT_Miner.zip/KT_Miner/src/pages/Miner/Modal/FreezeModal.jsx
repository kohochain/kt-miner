import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class FreezeModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, amount, commit, level} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <div onClick={()=>{onClose()}} className={'miner-modal-cancel'}>取消</div>
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>正在参与抵押升级。
                            抵押成功后将进入考核期，考核成功后您的抵押本金将全额返还。</div>
                        <div className={'miner-modal-input-title'}>
                            抵押上将级别
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{level}星上将</div>
                        </div>
                        <div className={'miner-modal-input-title'}>
                            抵押数量
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{amount}</div>
                            <div className={'miner-p8'}>CNC</div>
                        </div>
                        <div className={'miner-btn'} style={{marginTop:"8vw"}} onClick={()=>{commit()}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default FreezeModal;
