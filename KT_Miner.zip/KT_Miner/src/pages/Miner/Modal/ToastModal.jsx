import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class ToastModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, rows, title} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width: "100vw", height: "100vh"}}>
                    <div className={'flex-center-col miner-toast'}>
                        <div style={{color: "#8E9594",
                            fontSize: "4.27vw"}}>{title}</div>
                        <div style={{maxHeight:"60vh", overflow:"auto"}}>
                            {rows.map((item, index)=> {
                                return <div key={index} className={'miner-toast-text'}>
                                    {rows[index]}
                                </div>
                            })}
                        </div>
                        <div className={'kt-btn'} style={{marginTop: "8vw", width:"68vw"}} onClick={() => {
                            onClose()
                        }}>
                            知道了
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default ToastModal;
