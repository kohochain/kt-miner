import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class MinerModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, amount, commit} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <div onClick={()=>{onClose()}} className={'miner-modal-cancel'}>取消</div>
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>正在参与CNC抵押挖矿，抵押需要链上确认，如有延迟请您耐心等待，链上交易需要收取极少的MDC作为合约服务费。</div>
                        <div className={'miner-modal-input-title'}>
                            抵押数量
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{amount}</div>
                            <div className={'miner-p8'}>CNC</div>
                        </div>
                        <div className={'miner-btn'} style={{marginTop:"8vw"}} onClick={()=>{commit()}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default MinerModal;
