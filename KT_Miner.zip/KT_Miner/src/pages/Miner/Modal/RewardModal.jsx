import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";
import BigNumber from "bignumber.js";

class RewardModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, amount, commit, rate, feeRate, burnReward} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <div onClick={()=>{onClose()}} className={'miner-modal-cancel'}>取消</div>
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>收益的10%将根据CNC实时价格折算为子链优先认购权。领取奖励为链上交易，需要收取极少的MDC作为合约服务费。如有延迟请您耐心等待。</div>
                        <div className={'flex-between'}>
                            <div className={'miner-modal-input-title'}>
                                收益总量
                            </div>
                            <div className={'miner-modal-input-title'}>
                                每次领取收取1%的手续费
                            </div>
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{amount}</div>
                            <div className={'miner-p8'}>CNC</div>
                        </div>
                        <div className={'miner-modal-input-title'}>
                            到手数量
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{new BigNumber(amount).times(1 - rate - feeRate).toFixed(4,1)}</div>
                            <div className={'miner-p8'}>CNC</div>
                        </div>
                        <div className={'miner-modal-input-title'}>
                            优先认购权
                        </div>
                        <div className={'miner-modal-input flex-between'}>
                            <div className={'miner-p8'}>{burnReward}</div>
                            <div className={'miner-p8'}>USDT</div>
                        </div>
                        <div className={'miner-btn'} onClick={()=>{commit()}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default RewardModal;
