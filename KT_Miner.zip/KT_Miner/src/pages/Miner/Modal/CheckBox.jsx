import React, { Component } from 'react';

class CheckBox extends Component {
    render() {
        const { checked, onChange } = this.props;

        return checked ? (
            <img onClick={() => onChange(false)}
                 src={require('../../../images/resonance/checked.png')}
                 className="miner-modal-checked"
            />
        ) : (
            <div
                className="miner-modal-check"
                onClick={() => onChange(true)}
            />
        )
    }
}

export default CheckBox;
