import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import {Input} from "../Swap/components";
import FreezeModal from "./Modal/FreezeModal";
import UnfreezeModal from "./Modal/UnfreezeModal";
import {getCNCContract, getMiningContract} from "../../utils/mdc";
import {extensionErr} from "../../lib";

const miningContractAddress = process.env.REACT_APP_CNC_MINING_CONTRACT;

class Assessment extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab: 0,
            guaranteeList:[]
        }
    }

    componentDidMount(){
        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerGlobalInfo({address:address}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    renderCheck(){

        const {guaranteeDay} = this.state;

        return (<div className={'miner-card'} style={{marginTop:"5.33vw"}}>
            <div style={{padding:"5.33vw"}}>
                <div className={'miner-p9'}>
                    距离二星上将考核通过还有{guaranteeDay}天
                </div>
            </div>
        </div>)
    }

    getGuarantee(){
        const {guaranteeList, tab, guaranteeLevel} = this.state;

        if(guaranteeLevel)
        {
            if(tab){
                return guaranteeList.length ? guaranteeList[0]:0;
            }
            return guaranteeList.length > 1 ? (Number(guaranteeList[1]) - Number(guaranteeList[0])):0;
        }
        else {
            if(tab){
                return guaranteeList.length ? guaranteeList[0]:0;
            }
            return guaranteeList.length > 1 ? guaranteeList[1]:0;
        }
    }

    async check(){
        const {mdc, cnc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        if(this.getGuarantee() > cnc)
        {
            Toast.fail('CNC余额不足');
            return;
        }

        let contract = await getCNCContract();

        Toast.loading('提交中', 0);

        contract.approve(miningContractAddress, window.MDCExtension.toSun(this.getGuarantee())).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async unfreeze(){
        const {mdc, cnc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        if(this.getGuarantee() > cnc)
        {
            Toast.fail('CNC余额不足');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await getMiningContract();

        contract.freezeLevel(this.getGuarantee()).send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {

                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }
            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.unfreeze();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    checkHash(hash) {
        window.MDCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret2 ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.hide();
                Toast.success("操作成功，稍后查看，请勿重复");
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    freeze(){

    }

    renderAssessment(){

        const {guaranteeList, tab, guaranteeLevel, level} = this.state;

        return (
            <div className={'miner-card'} style={{marginTop:"5.33vw"}}>
                <div style={{padding:"5.33vw"}}>
                    <div className={'miner-p9'}>
                        选择您要升级的上将级别并进行抵押
                    </div>
                    <div className={'miner-p4'} style={{marginTop:"2vw", lineHeight:"5.33vw"}}>
                        若您抵押后未升级成功，请您耐心等待，请勿重复提交；若长时间内未升级成功，您可选择联系客服，我们将第一时间为您解决。
                    </div>
                    <div className={'miner-p9'} style={{marginTop:"8vw"}}>
                        上将级别
                    </div>
                    <div className={'flex-between'} style={{marginTop:"2.67vw"}}>
                        {(guaranteeLevel && guaranteeLevel < 1) || (level === 0 && !guaranteeLevel) ? <div onClick={() => {
                            this.setState({tab: 1})
                        }} className={tab === 1 ? 'miner-assessment-select flex-center' : 'miner-assessment-unselect flex-center'}>
                            <div className={tab === 1 ? 'miner-assessment-select-p' : 'miner-assessment-unselect-p'}>一星上将
                            </div>
                        </div> : null}
                        <div onClick={()=>{this.setState({tab:0})}} className={tab === 0 ? 'miner-assessment-select flex-center' : 'miner-assessment-unselect flex-center'}>
                            <div className={tab === 0 ? 'miner-assessment-select-p' : 'miner-assessment-unselect-p'}>二星上将</div>
                        </div>
                        {/*<div className={'miner-assessment-unselect flex-center'}>*/}
                        {/*    <div className={'miner-assessment-unselect-p'}>二星上将</div>*/}
                        {/*</div>*/}
                    </div>
                    <div className={'flex-between'} style={{marginTop:"8vw"}}>
                        <div className={'miner-p9'}>
                            抵押数量
                        </div>
                        <div className={'miner-p2'}>
                            {this.getGuarantee()} CNC
                        </div>
                    </div>
                    <div onClick={()=>{this.setState({freezeVisible:true})}} className={'miner-btn'} style={{width:"78.67vw"}}>
                        抵押
                    </div>
                </div>
            </div>
        )
    }

    renderRule(){
        return (
            <div className={'miner-card'} style={{marginTop:"5.33vw"}}>
                <div style={{padding:"5.33vw"}}>
                    <div className={'miner-p8'} style={{lineHeight:"7.47vw"}}>
                        抵押升级说明
                    </div>
                    <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"2vw"}}>
                        用户可以通过抵押规定数量的CNC提前享受一星上将和二星上将的分红权益。
                    </div>
                    <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"2vw"}}>
                        1.抵押升级：升级一星上将需要抵押300CNC、升级二星上将需要抵押800CNC，完成抵押的次日0点开始获得全球分红算力加成。
                    </div>
                    <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"2vw"}}>
                        2.抵押考核：抵押用户需要接受考核，一星上将考核天数为20天，二星上将考核天数为30天。
                    </div>
                    <div className={'miner-p8'} style={{lineHeight:"7.47vw", marginTop:"2vw"}}>
                        在规定的考核时间截止前完成对应上将的大、小区抵押要求，则抵押的本金退回。若在规定的考核时间截止前未完成对应的星级抵押要求，则用户参与抵押的CNC将进行通缩销毁。
                    </div>
                </div>
            </div>
        )
    }

    render() {

        const {tab, guaranteeLevel, freezeVisible} = this.state;

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#F4FAF9"}}>
                <FreezeModal visible={freezeVisible} onClose={()=>{this.setState({freezeVisible:false})}}
                               amount={this.getGuarantee()} level={tab === 0 ? 2:1} commit={()=>{
                    this.setState({freezeVisible:false});
                    this.check();
                }}/>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>抵押升级</div>
                    {/*<div className={'miner-p3'}>升级说明</div>*/}
                </div>
                <div className={'flex-display-col'}>
                    <div className={'miner-assessment-bg flex-center-col'}>
                        <div style={{color:"#2DBBAF", fontSize:"4.27vw", fontWeight:"bold"}}>
                            个人抵押极速升级
                        </div>
                        <div style={{color:"#2DBBAF", fontSize:"4.27vw", fontWeight:"bold"}}>
                            考核通过全额退回
                        </div>
                    </div>
                    {this.renderAssessment()}
                    {/*{guaranteeLevel === 2 ? this.renderCheck() : this.renderAssessment()}*/}
                    {this.renderRule()}
                </div>
            </div>
        );
    }
}

export default connect(Assessment);
