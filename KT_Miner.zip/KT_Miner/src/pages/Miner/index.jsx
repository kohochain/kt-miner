import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import {Input} from "../Swap/components";
import checkValue from "../../utils/checkValue";
import {extensionErr, inuputCheck} from "../../lib";
import BigNumber from "bignumber.js";
import MinerModal from "./Modal/MinerModal";
import {getCNCContract, getMiningContract, getPurchaseContract, getResonanceContract, getICSContract, isRegistered} from "../../utils/mdc";
import UnfreezeModal from "./Modal/UnfreezeModal";
import RewardModal from "./Modal/RewardModal";
import BecomeNode from "./Modal/BecomeNode";
import copy from "copy-to-clipboard";
import ToastModal from "./Modal/ToastModal";

const miningContractAddress = process.env.REACT_APP_CNC_MINING_CONTRACT;
const c2cAddress = process.env.REACT_C2C_ADDRESS;

const rows1 = ["当用户地址连续抵押CNC达到一定天数时，即可获得时间系数加成。", "时间系数加成可放大用户的静态算力，加持在用户有效算力上。", "时间系数加成规则如下：",
    "连续抵押天数≥20天，时间系数加成20%；", "连续抵押天数≥40天，时间系数加成40%；", "连续抵押天数≥60天，时间系数加成60%；", "连续抵押天数≥80天，时间系数加成80%；",
    "连续抵押天数≥100天，时间系数加成100%", "用户解除抵押后激励系数立即归零，再次抵押则重新开始计算抵押天数。"];
const rows2 = ["用户进行线下学习并通过市场考核，由市场提交名单后可获得学习算力。", "该部分用户可连续30天获得学习成长算力，用户每日可获的学习成长算力=5%×（用户当日的静态算力+用户当日的团队激励算力）。",
    "用户每邀请一个有效账户，发放天数增加10天，有效账户=抵押CNC数量≥100的账户。", "用户每日最多可获的学习算力等于用户当日的静态算力"];

class Index extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab: 0,
            tab2:0,
            guaranteeAfter:0,
            amount:"",
            amountErr:"",
            unfreezeTimeLabel:"-",
            minerVisible:false,
            becomeNode:false,
            isRegister:false,
            timeRateVisible:false,
            pause:null
        }
    }

    componentDidMount(){
        this.login();
    }



    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {
            this.getData(1);
            this.timer = setInterval(() => {
                this.getData();
            }, 5000);
        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    async getData(type){

        const {address} = this.props.redux;

        net.getMinerAddressInfo({address:address}).then(res => {
            if(type){
                Toast.hide();
            }
            if(res.response_code === '00')
            {
                this.setState(res.content);
                if(type){
                    this.timer = setInterval(() => {
                        this.openTimes();
                    }, 1000);
                }
            }
            else {
                Toast.fail(res.response_msg);
            }
        });

        net.getMinerGlobalInfo({address:address}).then(res => {
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });

        if(!this.state.isRegister)
        {
            let isRegister = await isRegistered();
            console.log("isRegister", isRegister);
            this.setState({isRegister:isRegister});
        }
    }

    async getRegister(){
        return await isRegistered();
    }

    async getContract(){
        if(!this.contract){
            this.contract = await getMiningContract();
        }

        return this.contract;
    }

    getValue(value, number, mode)
    {
        return checkValue(value, number, mode ? 0 : mode);
    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getAfterGuarantee(){

        const {frozen, guaranteeRate, amount} = this.state;

        if(!guaranteeRate || amount === "")
            return "-";

        return new BigNumber(guaranteeRate).times(amount).plus(frozen).toNumber();
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    checkInput(val) {  // 0 数量 1 单价 2 最小交易数量 3 最大交易数量
        let value = inuputCheck(val,  4);
        let isInt = false;
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {

        } else {
            value = value ? Number(value) : '';
        }

        if(parseInt(value) === Number(value))
            isInt = true;

        // const { balance, withdrawFee} = this.props;
        const {cnc} = this.props.redux.balance;

        const {frozenLimit, frozen} = this.state;
        const remain = new BigNumber(frozenLimit).minus(frozen).toNumber();

        this.setState({amount:value});
        if (value < 1)
        {
            this.setState({amountErr:"抵押数量不得小于1"});
        }
        else if(!isInt)
        {
            this.setState({amountErr:"最小抵押单位不得小于1"});
        }
        else if(value > Number(cnc))
        {
            this.setState({amountErr:"CNC余额不足"});
        }
        else if (value > remain)
        {
            this.setState({amountErr:"最大可抵押数量不足"});
        }
        else {
            this.setState({amountErr:""});
        }
    }

    openTimes(){

        const date = this.state.unfreezeTime;

        if(date === undefined || date === null)
        {
            this.setState({unfreezeTimeLabel:"-"});
            return;
        }

        let date3 = (date - moment().valueOf())/1000;   //时间差的毫秒数

        if(date3 < 0)
        {
            this.setState({unfreezeTimeLabel:"-"});
            clearTimeout(this.timer) && (this.timer = null);
            return;
        }

        let leave1= date3 %(24*3600);    //计算天数后剩余的毫秒数
        let hours= Math.floor(date3/(3600));
        //计算相差分钟数
        let leave2 = leave1 % (3600) ;       //计算小时数后剩余的毫秒数
        let minutes = Math.floor(leave2/(60));
        //计算相差秒数
        let leave3 = leave2 % (60) ;     //计算分钟数后剩余的毫秒数
        let seconds = Math.round(leave3);

        let label = (hours < 10 ? ("0" + hours) : hours) + ":" +  (minutes < 10 ? ("0" + minutes) : minutes) + ":" +  (seconds < 10 ? ("0" + seconds) : seconds);

        this.setState({unfreezeTimeLabel:label});
    }


    async miningCheck(){
        const {mdc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        let contract = await getCNCContract();

        Toast.loading('提交中', 0);

        contract.approve(miningContractAddress, window.MDCExtension.toSun(this.state.amount)).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async unfreeze(){
        const {mdc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await this.getContract();

        let fee = await contract.fee().call();

        fee = window.MDCExtension.toDecimal(fee);

        contract.unfreeze().send({callValue:fee}).then(res => {
            this.checkHash(res);
        }).catch(
            res => {

                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async getReward(){
        const {mdc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await this.getContract();

        contract.getReward().send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {

                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async asyncActive(){

        const {mdc} = this.props.redux.balance;
        if(mdc === 0)
        {
            Toast.fail('MDC余额为0，不足支付交易手续费');
            return;
        }

        const contract = await getICSContract();
        // const contract = await getResonanceContract();

        Toast.loading('提交中', 0);

        contract.approve(miningContractAddress, window.MDCExtension.toSun(this.state.amount)).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }
            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.mining();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    async mining(){
        Toast.loading('提交中', 0);

        const contract = await this.getContract();
        contract.freeze(this.state.amount).send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {

                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    checkHash(hash) {
        window.MDCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret2 ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.hide();
                Toast.success("操作成功，稍后查看");
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    getBurnReward(){
        const {leftMineReward, rewardBurnRate, cncPrice} = this.state;

        return new BigNumber(leftMineReward).times(rewardBurnRate).times(cncPrice).toFixed(4, 1);
    }

    renderCard(){

        const {tab, invitationCode, active, isRegister} = this.state;

        return (
            <div className={"miner-green-card"}>
                <div className={'flex-center'}>
                    {active && isRegister ? <div className={'miner-top-card flex-col-end-s'} style={{marginRight:"4vw"}}>
                        <div className={'miner-top-card-p1'}>
                            我的邀请码
                        </div>
                        {invitationCode ? <div className={'miner-top-card-p1'}>
                            {invitationCode}
                        </div> : null}
                        <div className={'miner-top-card-card flex-center'}>
                            <div onClick={() => {
                                copy(invitationCode || '-');
                                Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                            }} className={'miner-top-card-p2'}>
                                复制邀请码
                            </div>
                        </div>
                    </div> : <div className={'miner-top-card flex-col-end-s'} style={{marginRight:"4vw"}}>
                        <div className={'miner-top-card-p1'}>
                            激活账号
                        </div>
                        <div className={'miner-top-card-p1'}>
                            获得邀请码
                        </div>
                        <div onClick={()=>{this.setState({becomeNode:true})}} className={'miner-top-card-card flex-center'}>
                            <div className={'miner-top-card-p2'}>
                                激活账号
                            </div>
                        </div>
                    </div>}
                    <div className={'miner-top-card flex-col-end-s'}>
                        <div className={'miner-top-card-p1'}>
                            CNC链上交易区
                        </div>
                        <div className={'miner-top-card-card flex-center'}>
                            <div onClick={()=>{window.location.href = "https://cnc.magicdata.io/#/trade"}} className={'miner-top-card-p2'}>
                                前往交易
                            </div>
                        </div>
                    </div>
                </div>
                <div className={"miner-card"} style={{marginTop:"5.33vw"}}>
                    <div className={'miner-select-header flex-display'}>
                        <div onClick={()=>{this.setState({tab:0})}} className={'miner-select-header-sub flex-col-end-s'} style={{borderRightWidth:"0.013vw", borderRightColor:"#EBEEEE"}}>
                            <div className={tab === 1 ? 'miner-select-header-unselect-p':'miner-select-header-select-p'}>
                                个人
                            </div>
                            <div className={tab === 1 ? 'miner-select-header-unselect-bottom':'miner-select-header-select-bottom'} />
                        </div>
                        <div onClick={()=>{this.setState({tab:1})}} className={'miner-select-header-sub flex-col-end-s'}>
                            <div className={tab === 0 ? 'miner-select-header-unselect-p':'miner-select-header-select-p'}>
                                全网
                            </div>
                            <div className={tab === 0 ? 'miner-select-header-unselect-bottom':'miner-select-header-select-bottom'} />
                        </div>
                    </div>
                    <div style={{padding:"0 4vw", paddingBottom:"6.67vw"}}>
                        {tab === 0 ? <div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    个人累计挖矿
                                </div>
                                <div className={'flex-display'}>
                                    <div className={"miner-p2"}>
                                        {this.getValue(this.state.mineReward)} CNC
                                    </div>
                                    <div onClick={()=>{this.props.history.push(`/mortgage`)}} className={"miner-p3"} style={{marginLeft:"2.53vw"}}>
                                        详情
                                    </div>
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={'flex-display'}>
                                    <div className={"miner-p1"}>
                                        个人今日预计可挖
                                    </div>
                                    <img onClick={() => {
                                        this.setState({userVisible: true})
                                    }} className={"miner-info"} style={{marginLeft: "1vw"}}
                                         src={require('../../images/miner/info.png')}/>
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getValue(this.state.userPredictMine)} CNC
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    个人有效算力
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.effectiveGuarantee)}
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    个人优先认购权
                                </div>
                                <div className={'flex-display'}>
                                    <div className={"miner-p2"}>
                                        {this.getValue(this.state.burnReward)} USDT
                                    </div>
                                    <div onClick={() => {
                                        this.props.history.push(`/subscription`)
                                    }} className={"miner-p3"} style={{marginLeft: "2.53vw"}}>
                                        详情
                                    </div>
                                </div>
                            </div>
                        </div> : <div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    全网累计产矿
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getValue(this.state.totalMined)} CNC
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={'flex-display'}>
                                    <div className={"miner-p1"}>
                                        今日预计全网可挖
                                    </div>
                                    <img onClick={() => {
                                        this.setState({userVisible: true})
                                    }} className={"miner-info"} style={{marginLeft: "1vw"}}
                                         src={require('../../images/miner/info.png')}/>
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getValue(this.state.predictMine)} CNC
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    全网会员有效算力
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.totalEffectiveGuarantee)}
                                </div>
                            </div>
                            <div className={"miner-card-row flex-between"}>
                                <div className={"miner-p1"}>
                                    全网优先认购权
                                </div>
                                <div className={"miner-p2"}>
                                    {this.getValue(this.state.totalBurnReward)} USDT
                                </div>
                            </div>
                        </div>}
                    </div>
                </div>
                {active && isRegister ? <div className={"miner-card"} style={{marginTop:"5.33vw"}}>
                    <div className={"miner-card-header flex-center"}>
                        <div className={"miner-card-header-p"}>
                            有效算力详情
                        </div>
                    </div>
                    <div style={{padding:"0 4vw", paddingBottom:"6.67vw"}}>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                当前静态算力
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.frozenGuarantee)}
                                </div>
                                <div onClick={()=>{this.props.history.push(`/static`)}} className={"miner-p3"} style={{marginLeft:"2.53vw"}}>
                                    详情
                                </div>
                            </div>
                        </div>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                时间系数加成比例
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.getRate(this.state.dayCountRate)}
                                </div>
                                <img onClick={()=>{this.setState({timeRateVisible:true})}} className={"miner-info"} style={{marginLeft:"2.53vw"}} src={require('../../images/miner/info.png')} />
                            </div>
                        </div>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                学习算力
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.state.learnGuarantee === null ? 0 : this.getGuarantee(this.state.learnGuarantee)}
                                </div>
                                <img onClick={()=>{this.setState({learnVisible: true})}} className={"miner-info"} style={{marginLeft:"2.53vw"}} src={require('../../images/miner/info.png')} />
                            </div>
                        </div>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                团队激励算力
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.groupGuarantee)}
                                </div>
                                <div onClick={()=>{this.props.history.push(`/group`)}} className={"miner-p3"} style={{marginLeft:"2.53vw"}}>
                                    详情
                                </div>
                            </div>
                        </div>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                全球分红算力
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.globalGuarantee)}
                                </div>
                                <div onClick={()=>{this.props.history.push(`/power`)}} className={"miner-p3"} style={{marginLeft:"2.53vw"}}>
                                    详情
                                </div>
                            </div>
                        </div>
                        <div className={"miner-card-row flex-between"}>
                            <div className={"miner-p1"}>
                                共享矿池算力
                            </div>
                            <div className={'flex-display'}>
                                <div className={"miner-p2"}>
                                    {this.getGuarantee(this.state.shareGuarantee)}
                                </div>
                                <div onClick={()=>{this.props.history.push(`/pool`)}} className={"miner-p3"} style={{marginLeft:"2.53vw"}}>
                                    详情
                                </div>
                            </div>
                        </div>
                    </div>
                </div> : null}
            </div>
        )
    }

    renderBottom(){

        const {frozenLimit, frozen, tab2, amountErr, amount, active, isRegister, pause} = this.state;
        const cnc = !frozenLimit ? "-" : new BigNumber(frozenLimit).minus(frozen).toNumber();

        let systemTime = false;

        if(Number(moment().format("HH")) === 23 && Number(moment().format("mm")) >= 50)
        {
            systemTime = true;
        }

        if(Number(moment().format("HH")) === 0 && Number(moment().format("mm")) <= 5)
        {
            systemTime = true;
        }

        const ContractPause = pause === 1;

        const MinerDisable = amountErr || !amount || amount === "" || !active || !isRegister || systemTime || ContractPause;
        const unFreezeDisable = !frozen || ContractPause || systemTime || !active || !isRegister;

        return (
            <div>
                <div className={'miner-select-header flex-display'}>
                    <div onClick={()=>{this.setState({tab2:0})}} className={'miner-select-header-sub flex-col-end-s'} style={{borderRightWidth:"0.013vw", borderRightColor:"#EBEEEE"}}>
                        <div className={tab2 === 1 ? 'miner-select-header-unselect-p':'miner-select-header-select-p'}>
                            抵押
                        </div>
                        <div className={tab2 === 1 ? 'miner-select-header-unselect-bottom':'miner-select-header-select-bottom'} />
                    </div>
                    <div onClick={()=>{this.setState({tab2:1})}} className={'miner-select-header-sub flex-col-end-s'}>
                        <div className={tab2 === 0 ? 'miner-select-header-unselect-p':'miner-select-header-select-p'}>
                            释放
                        </div>
                        <div className={tab2 === 0 ? 'miner-select-header-unselect-bottom':'miner-select-header-select-bottom'} />
                    </div>
                </div>
                <div className={'flex-display-col'} style={{padding:"5.33vw"}}>
                    {this.state.leftMineReward ? <div>
                        <div className={'miner-reward flex-between'}>
                            <div className={'miner-reward-p1'}>
                                待领取抵押收益：{this.getValue(this.state.leftMineReward, 4, 1)} CNC
                            </div>
                            {!ContractPause ? <div className={'flex-display'}>
                                <div onClick={()=>{this.setState({rewardVisible:true})}} className={'miner-p3'}>领取</div>
                                <img alt="" src={require('../../images/miner/more.png')} style={{width:"5.6vw", height:"5.6vw"}}/>
                            </div> : null}
                        </div>
                        <div style={{color:"#8E9594", fontSize:"3.2vw", textAlign:"right", marginTop:"2.4vw"}}>
                            每次领取时收取1%手续费
                        </div>
                    </div> : null}
                    {tab2 === 0 ? <div>
                            <div className={'flex-start'} style={{width: '89.33vw', marginBottom: "-2vw", marginTop:"5.33vw"}}>
                                {/*<div className={'common-input-label'} style={{margin: "0"}}>预计可获得CNC数量</div>*/}
                                <div className={'common-input-label'} style={{margin: "0"}}>当前最大可抵押数量 ：{cnc} CNC</div>
                            </div>
                            <Input
                                width={'81.33vw'}
                                // title={'设置联动警戒线（选填）' /*交易金额*/}
                                tag={'CNC'}
                                // onBlur={()=>{
                                //     this.setState({type:1}, ()=>{
                                //         this.getAmount(1);
                                //     })
                                // }}
                                value={this.state.amount}
                                error={this.state.amountErr}
                                onChange={(val) => {
                                    this.checkInput(val)
                                }}
                            />
                            <div style={{width:"89.33vw", marginTop:"2.67vw"}}>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        当前静态算力
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getGuarantee(this.state.frozenGuarantee)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        当前抵押天数
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getGuarantee(this.state.dayCount)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        抵押后静态算力
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getAfterGuarantee()}
                                    </div>
                                </div>
                            </div>
                            {/*<div onClick={disable ? ()=>{} : ()=>{*/}
                            {/*    this.purchaseCheck();*/}
                            {/*}}  className={disable ? 'miner-btn-disable' : 'miner-btn'}>*/}
                            {/*    {this.state.roundList.length ? (flag ? "每日11:50~13:17为非联动时间" : "联 动") : (this.state.asset.toUpperCase() + "联动池无可联动余量")}*/}
                            {/*</div>*/}
                            <div className={MinerDisable ? 'miner-btn-disable' : 'miner-btn'} onClick={MinerDisable ? ()=>{} : ()=>{this.setState({minerVisible:true})}}>
                                {ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间" :(active && isRegister ? "抵押": "请先激活账号"))}
                            </div>
                        </div>:
                        <div>
                            <div style={{width:"89.33vw", marginTop:"2.67vw"}}>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        抵押中数量
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getGuarantee(this.state.frozen)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        释放中数量
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.getGuarantee(this.state.unfreezing)}
                                    </div>
                                </div>
                                <div className={"miner-card-row flex-between"}>
                                    <div className={"miner-p1"}>
                                        释放倒计时
                                    </div>
                                    <div className={"miner-p2"}>
                                        {this.state.unfreezeTimeLabel}
                                    </div>
                                </div>
                            </div>
                            {/*<div onClick={disable ? ()=>{} : ()=>{*/}
                            {/*    this.purchaseCheck();*/}
                            {/*}}  className={disable ? 'miner-btn-disable' : 'miner-btn'}>*/}
                            {/*    {this.state.roundList.length ? (flag ? "每日11:50~13:17为非联动时间" : "联 动") : (this.state.asset.toUpperCase() + "联动池无可联动余量")}*/}
                            {/*</div>*/}
                            <div onClick={!unFreezeDisable ? ()=>{this.setState({unfreezeVisible:true})} : ()=>{}} className={!unFreezeDisable ? 'miner-btn':"miner-btn-disable"}>
                                {ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间" :(active && isRegister ? (frozen ? "释放":"暂无抵押中CNC"): "请先激活账号"))}
                            </div>
                    </div>}
                </div>
            </div>
        )
    }

    render() {

        let {userVisible, learnVisible, timeRateVisible, minerVisible, amount, unfreezeVisible, frozen, rewardVisible, leftMineReward, withdrawFeeRate, rewardBurnRate, burnReward, becomeNode, active, isRegister} = this.state;
        const {address, balance} = this.props.redux;

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner">
                <MinerModal visible={minerVisible} onClose={()=>{this.setState({minerVisible:false})}}
                            amount={amount} commit={()=>{
                    this.setState({minerVisible:false});
                    this.miningCheck();
                }}
                />
                <UnfreezeModal visible={unfreezeVisible} onClose={()=>{this.setState({unfreezeVisible:false})}}
                               amount={frozen} commit={()=>{
                    this.setState({unfreezeVisible:false});
                    this.unfreeze();
                }}/>
                <RewardModal visible={rewardVisible} onClose={()=>{this.setState({rewardVisible:false})}}
                             amount={leftMineReward} rate={rewardBurnRate} feeRate={withdrawFeeRate} burnReward={this.getBurnReward()} commit={()=>{
                    this.setState({rewardVisible:false});
                    this.getReward();
                }}/>
                <ToastModal visible={timeRateVisible} onClose={()=>{this.setState({timeRateVisible:false})}} title={"时间系数加成"}
                            rows={rows1}
                />
                <ToastModal visible={learnVisible} onClose={()=>{this.setState({learnVisible:false})}} title={"学习算力说明"}
                            rows={rows2}
                />
                <ToastModal visible={userVisible} onClose={()=>{this.setState({userVisible:false})}} title={""}
                            rows={["此为预估数量，实际挖矿数量以结算时的数据为准"]}
                />

                <BecomeNode
                    visible={becomeNode}
                    onClose={() => this.setState({ becomeNode: false })}
                    isRegistered={isRegister}
                    balance={balance}
                    address={address}
                    deviceId={""}
                />

                <div className={"flex-display"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw"}}>
                    <div style={{fontSize:"4.53vw", color:"#103533", fontWeight:"bold"}}>团队激励算力</div>

                </div>
                {this.renderCard()}
                {this.renderBottom()}
            </div>
        );
    }
}

export default connect(Index);
