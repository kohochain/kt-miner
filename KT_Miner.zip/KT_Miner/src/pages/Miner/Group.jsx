import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import checkValue from "../../utils/checkValue";
import BigNumber from "bignumber.js";
import ToastModal from "./Modal/ToastModal";


const imgs = {"rank1":require('../../images/kt/rank1.png'), "rank2":require('../../images/kt/rank2.png'), "rank3":require('../../images/kt/rank3.png'),
    "done":require('../../images/kt/done.png')};

const rows = ["作为其生态贡献奖励，用户从自身往下三代的邀请下级的静态算力（包含时间加成系数和KHC聚合算力加成系数），可以一定的比例加成到会员个人的有效算力中。",
    "具体比例与个人抵押KT数目和三代内总抵押KT数量相关。",
"最终可获得的加成级数与用户直接推荐的有效用户数有关。",
    "用户直推推荐1位有效用户，用户可获得第1级的算力加成；用户直推推荐2位有效用户，用户可获得第1级和第2级的算力加成；用户直推推荐3位有效用户，用户可获得第1级、第2级和第3级的算力加成。",
    "算力的比例细则如下：（抵押数量单位均为KT）",
    "本人抵押数量≥100，三代内抵押数量无要求，用户可享受：一代下级10%的算力加成、第二代下级4%的算力加成以及三代下级2%的算力加成；",
"本人抵押数量≥500，三代内抵押数量≥1万，用户可享受：一代下级15%的算力加成、第二代下级8%的算力加成以及三代下级4%的算力加成；",
    "本人抵押数量≥1000，三代内抵押数量≥3万，用户可享受：一代下级20%的算力加成、第二代下级12%的算力加成以及三代下级6%的算力加成；",
"本人抵押数量≥2000，三代内抵押数量≥5万，用户可享受：一代下级25%的算力加成、第二代下级16%的算力加成以及三代下级8%的算力加成；",
"本人抵押数量≥3000，三代内抵押数量≥8万，用户可享受：一代下级30%的算力加成、第二代下级20%的算力加成以及三代下级10%的算力加成。"];

class Group extends Component {

    constructor(props){
        super(props);
        this.state = {
            groupFrozenList: [],
            rateList: [],
            show: 0,
        }
    }

    getValue(value, number, mode)
    {
        return checkValue(value, number, mode ? 0 : mode);
    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    componentDidMount(){
        const {address} = this.props.redux;
        Toast.loading(intl.get('WAITING'), 0);

        net.getMinerGroupInfo({address:address}).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }



    componentWillUnmount() {

    }

    renderCard(){

        const {level, rateList, show, frozenNextLevel, frozen, groupFrozenNextLevel, groupFrozen} = this.state;

        return (
            <div style={{backgroundColor:"white", width:"100vw", borderRadius:"1.33vw"}}>
                <div className={'kt-p8'} style={{padding:"5.33vw", paddingBottom:"2.67vw"}}>当前共识挖矿算力比例</div>
                {rateList.length > 0 ? <div className={'flex-display-col'}>
                        <div className={'kt-group-color1 flex-center'}>
                            <img className={'kt-group-img'} src={imgs['rank1']}/>
                            <div style={{marginLeft:"5.33vw"}}>
                                <div className={'kt-group-p1'}>直推下级算力加成比例（第1级）</div>
                                <div className={'miner-p7'}>
                                    {this.getRate(rateList[0])}
                                </div>
                            </div>
                        </div>
                    {rateList.length > 1 ? <div className={'kt-group-color2 flex-center'}>
                        <img className={'kt-group-img'} src={imgs['rank2']}/>
                        <div style={{marginLeft:"5.33vw"}}>
                            <div className={'kt-group-p1'}>二代下级算力加成比例（第2级）</div>
                            <div className={'miner-p7'}>
                                {this.getRate(rateList[1])}
                            </div>
                        </div>
                    </div> : null}
                    {rateList.length > 2 ? <div className={'kt-group-color3 flex-center'}>
                        <img className={'kt-group-img'} src={imgs['rank3']}/>
                        <div style={{marginLeft:"5.33vw"}}>
                            <div className={'kt-group-p1'}>三代下级算力加成比例（第3级）</div>
                            <div className={'miner-p7'}>
                                {this.getRate(rateList[2])}
                            </div>
                        </div>
                    </div> : null}
                    </div> : <div className={'miner-power-bg flex-center'} style={{height:"18.67vw"}}>
                    <div className={'miner-p5'}>再努力一下就可以获得共识挖矿算力啦～</div>
                    </div>}
                {show ? <div style={{textAlign:"center", marginTop:"5.33vw"}} className={'kt-group-p1'}>完成以下条件，获得更高算力加成（每小时更新）</div> : null}
                {show ? <div className={'flex-center'} style={{paddingBottom:"5.33vw"}}>
                    <div className={frozen >= frozenNextLevel ? 'kt-group-condition1 relative flex-center-col' : 'kt-group-condition2 relative flex-center-col'} style={{marginRight:"4vw"}}>
                        {(frozen >= frozenNextLevel) ? <img className={'kt-group-done'} src={imgs['done']} /> : null}
                        <div className={'kt-group-p1'}>
                            本人抵押≥{frozenNextLevel >= 0 ? Math.floor(frozenNextLevel * 100) / 100 : '-'}
                        </div>
                        <div className={'kt-group-p2'}>
                            {frozen >= 0 ? Math.floor(frozen * 100) / 100 : '-'}/{frozenNextLevel ? Math.floor(frozenNextLevel * 100) / 100 : '-'}
                        </div>
                    </div>
                    <div className={groupFrozen >= groupFrozenNextLevel ? 'kt-group-condition1 relative flex-center-col' : 'kt-group-condition2 relative flex-center-col'}>
                        {groupFrozen >= groupFrozenNextLevel ? <img className={'kt-group-done'} src={imgs['done']} /> : null}
                        <div className={'kt-group-p1'}>
                            三代内抵押数≥{groupFrozenNextLevel >= 0 ? Math.floor(groupFrozenNextLevel * 100) / 100 : '-'}
                        </div>
                        <div className={'kt-group-p2'}>
                            {groupFrozen >= 0 ? Math.floor(groupFrozen * 100) / 100 : '-'}/{groupFrozenNextLevel ? Math.floor(groupFrozenNextLevel * 100) / 100 : '-'}
                        </div>
                    </div>
                </div> : null}

                {/*<div className={'miner-power-bg'} style={{marginTop:"5.33vw"}}>*/}
                {/*    <div className={'flex-center'}>*/}
                {/*        <div>*/}
                {/*            <div className={'miner-card-row flex-center'}>*/}
                {/*                <div className={'miner-p5'}>再努力一下就可以获得共识挖矿算力啦～</div>*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*    </div>*/}
                {/*    {show ? <div style={{paddingLeft:"5.33vw", paddingRight:"4.4vw", paddingBottom:"5.33vw"}}>*/}
                {/*        <div className={'miner-p5'} style={{marginTop:"5.33vw"}}>完成以下条件，获得更高团队加成(0点升级)</div>*/}
                {/*        <div className={'miner-power-bg-row flex-between'}>*/}
                {/*            <div className={'flex-display'}>*/}
                {/*                <div className={'miner-p5'}>1.本人抵押≥{frozenNextLevel >= 0 ? Math.floor(frozenNextLevel * 100) / 100 : '-'}}</div>*/}
                {/*                {(frozen >= frozenNextLevel) ? <img src={require('../../images/miner/done.png')} alt="" style={{width:"3.47vw", height:"3.47vw", marginLeft:"2.67vw"}}/> : null}*/}
                {/*            </div>*/}
                {/*            <div className={'miner-p6'}>*/}
                {/*                {frozen >= 0 ? Math.floor(frozen * 100) / 100 : '-'}/{frozenNextLevel ? Math.floor(frozenNextLevel * 100) / 100 : '-'}*/}
                {/*            </div>*/}
                {/*        </div>*/}
                {/*        {groupFrozenNextLevel === 0 ? null : <div className={'miner-power-bg-row flex-between'}>*/}
                {/*            <div className={'flex-display'}>*/}
                {/*                <div className={'miner-p5'}>2.三代内抵押数≥{groupFrozenNextLevel >= 0 ? Math.floor(groupFrozenNextLevel * 100) / 100 : '-'}</div>*/}
                {/*                {groupFrozen >= groupFrozenNextLevel ? <img src={require('../../images/miner/done.png')} alt="" style={{width:"3.47vw", height:"3.47vw", marginLeft:"2.67vw"}}/>*/}
                {/*                :null}*/}
                {/*            </div>*/}
                {/*            <div className={'miner-p6'}>*/}
                {/*                {groupFrozen >= 0 ? Math.floor(groupFrozen * 100) / 100 : '-'}/{groupFrozenNextLevel ? Math.floor(groupFrozenNextLevel * 100) / 100 : '-'}*/}
                {/*            </div>*/}
                {/*        </div>}*/}
                {/*    </div> : null}*/}
                {/*</div>*/}
            </div>
        )
    }

    renderBottom(){

        const {groupFrozenList, activeInviteCount, level} = this.state;

        let string = "";
        if(level) {
            for (let i = 0; i < level; i++)
            {
                if(i === level - 1) {
                    string += ((i + 1) + "级");
                }
                else {
                    string += ((i + 1) + "级、");
                }
            }

            string = "可获得" + string + "的共识挖矿算力加成";
        }

        return (
            <div className={'flex-display-col'} style={{marginTop:"5.33vw"}}>
                <div className={'kt-group-card'}>
                    <div className={'kt-group-card-gray flex-center-col'}>
                        <div className={'kt-p6'}>当前有效直推人数：{activeInviteCount}</div>
                        {level ? <div className={'kt-p9'} style={{marginTop:"3.73vw"}}>{string}</div> : null}
                    </div>
                    <div className={'kt-p8'} style={{margin:"5.33vw 0"}}>三代抵押情况总览</div>
                    <div className={'kt-group-card-row flex-between'}>
                        <div className={'kt-p6'}>直推下级静态算力</div>
                        <div className={'kt-p6'}>{groupFrozenList.length > 0 ? Math.floor(groupFrozenList[0] * 100) / 100 : 0}</div>
                    </div>
                    <div className={'kt-group-card-row flex-between'}>
                        <div className={'kt-p6'}>二代下级静态算力</div>
                        <div className={'kt-p6'}>{groupFrozenList.length >= 2 ? Math.floor(groupFrozenList[1] * 100) / 100 : 0}</div>
                    </div>
                    <div className={'kt-group-card-row flex-between'}>
                        <div className={'kt-p6'}>三代下级静态算力</div>
                        <div className={'kt-p6'}>{groupFrozenList.length >= 3 ? Math.floor(groupFrozenList[2] * 100) / 100 : 0}</div>
                    </div>
                </div>
            </div>
        )
    }

    render() {

        return (
            //style={{overflow:"hidden"}}

            <div className="page miner" style={{backgroundColor:"#EEF1FA"}}>
                <div className={"flex-between"} style={{width:"89.33vw", height:"11.73vw", padding:"0 5.33vw", backgroundColor:"white"}}>
                    <div className={'miner-p3'} style={{color:"transparent"}}>算力说明</div>
                    <div style={{fontSize:"4.53vw", color:"black", fontWeight:"bold"}}>共识挖矿算力</div>
                    <div onClick={()=>{this.setState({visible:true})}} className={'miner-p3'}>算力说明</div>
                </div>
                <ToastModal visible={this.state.visible} onClose={()=>{this.setState({visible:false})}} title={"共识挖矿算力说明"}
                            rows={rows}/>
                {this.renderCard()}
                {this.renderBottom()}
            </div>
        );
    }
}

export default connect(Group);
