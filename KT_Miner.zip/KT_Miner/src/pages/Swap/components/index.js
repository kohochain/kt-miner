import Tab from './Tab';
import Input from './Input';

export {
    Tab,
    Input
}