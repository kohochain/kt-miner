import React, { Component } from "react";
import {Modal, Toast} from 'antd-mobile';
import {Input} from "../index";
import intl from "react-intl-universal";
import connect from "../../../../store/connect";
import BigNumber from "bignumber.js";
import {extensionErr, inuputCheck} from "../../../../lib";
import {get20Contract} from "../../../../utils/mdc";

const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;

class ModalPool extends Component {

    constructor(props){
        super(props);
        this.state = {
            ratio:0,
            amount:0,
        }
    }

    componentDidMount() {

        // console.log("111");
        //
        // const {pool} = this.props;
        // let quantity = new BigNumber(this.getPoolById(pool.id));
        // let baseQuantity = new BigNumber(pool.baseQuantity);
        // let quoteQuantity = new BigNumber(pool.quoteQuantity);
        //
        // this.setState({amount:quantity.toFormat(4)});
        //
        // let proportion = quantity.div(baseQuantity).div(quoteQuantity).times(100).toFormat(2);
        //
        // this.setState({ratio:proportion});

    }

    getTokensById(id){

        let tokens = this.props.redux.tokenList;

        for(let i = 0;i < tokens.length; i++){
            if(tokens[i].id === id){
                return tokens[i];
            }
        }
        return {};
    };

    getShareById(id){
        let share = this.props.redux.account.share;

        for(let i = 0;i < share.length; i++){
            if(share[i].poolId === id){
                return share[i].quantity;
            }
        }
        return 0;
    }

    checkInput(val, index) {  // 0 数量 1 单价 2 最小交易数量 3 最大交易数量

        const {pool} = this.props;

        let baseQuantity = new BigNumber(pool.baseQuantity);
        let quoteQuantity = new BigNumber(pool.quoteQuantity);
        let ratio = quoteQuantity.div(baseQuantity);

        let value = inuputCheck(val,  4);
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {
        } else {
            value = value ? Number(value) : '';
        }
        if(index === 0)
        {
            this.setState({baseAmount:value, quoteAmount:value === '' ? 0 : new BigNumber(value).times(ratio).toFixed(4)});
            if(value > Number(this.getBalanceByTokenID(pool.baseToken)))
            {
                this.setState({baseAmountErr:"可用余额不足"})
            }
            else {
                this.setState({baseAmountErr:""})
            }

            if(new BigNumber(value).times(ratio).toFixed(4) > Number(this.getBalanceByTokenID(pool.quoteToken)))
            {
                this.setState({quoteAmountErr:"可用余额不足"})
            }
            else {
                this.setState({quoteAmountErr:""})
            }
        }
        else {
            this.setState({quoteAmount:value, baseAmount:value === '' ? 0 : new BigNumber(value).div(ratio).toFixed(4)});

            if(value > Number(this.getBalanceByTokenID(pool.quoteToken)))
            {
                this.setState({quoteAmountErr:"可用余额不足"})
            }
            else {
                this.setState({quoteAmountErr:""})
            }

            if(new BigNumber(value).div(ratio).toFixed(4) > Number(this.getBalanceByTokenID(pool.baseToken)))
            {
                this.setState({baseAmountErr:"可用余额不足"})
            }
            else {
                this.setState({baseAmountErr:""})
            }
        }
    }

    updateRatio(){

        const {pool} = this.props;

        let quantity = new BigNumber(this.getShareById(pool.id));
        let baseQuantity = new BigNumber(pool.baseQuantity);
        let quoteQuantity = new BigNumber(pool.quoteQuantity);
        let baseAmount = new BigNumber(this.state.baseAmount === '' ? 0:this.state.baseAmount);
        let quoteAmount = new BigNumber(this.state.quoteAmount === '' ? 0:this.state.quoteAmount);

        let amount = baseAmount.times(quoteAmount).plus(quantity);

        this.setState({amount:amount.toFormat(4)});

        let ratio = amount.div(baseQuantity.plus(baseAmount)).div(quoteQuantity.plus(quoteAmount)).times(100);

        this.setState({ratio:ratio.toFormat(2)})

    }

    getBalanceByTokenID(id){
        let token = this.getTokensById(id);

        let balances = this.props.redux.balances;

        if(token.name === 'MDC')
        {
            return  this.props.redux.balance.mdc;
        }

        for(let i = 0;i < balances.length; i++){
            if(balances[i].abbr === token.name){
                return new BigNumber(balances[i].balance).toFixed(4,1);
            }
        }
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.add2();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    getApproveResult2(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult2(res)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.invest();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult2(res);
        })
    }

    async add2(){

        const {pool} = this.props;

        let functions = await get20Contract(this.getTokensById(pool.quoteToken).contractAddress);

        functions.approve(contractAddress, this.toSun(pool.quoteToken, this.state.quoteAmount)).send().then(res => {
            this.getApproveResult2(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });


        // await get20Contract(this.getTokensById(pool.quoteToken).contractAddress, (functions) => {
        //     console.log('functions', functions);
        //     functions.approve(contractAddress, this.toSun(pool.quoteToken, this.state.quoteAmount)).send().then(res => {
        //         this.getApproveResult2(res);
        //     }).catch(
        //         res => {
        //             let err = extensionErr(res);
        //             Toast.fail(err, 2, () => {
        //             }, false);
        //         });
        // });
    }

    async add(){

        if(this.props.redux.balance.mdc === 0)
        {
            this.setState({modal3:true});
            return ;
        }

        Toast.loading(intl.get('WAITING'), 0);

        const {pool} = this.props;

        if (this.getTokensById(pool.baseToken).name === 'MDC') {
            window.MDCExtension.contract().at(contractAddress).then(functions => functions.invest(pool.baseToken, pool.quoteToken, this.toSun(pool.baseToken, this.state.baseAmount),
                this.toSun(pool.quoteToken, this.state.quoteAmount), 1).send({callValue:window.MDCExtension.toSun(this.state.baseAmount)}))
                .then(res => {
                    console.log('res', res);
                    if (res) {
                        this.checkHash(res);
                    } else {
                        Toast.fail('调用合约失败', 2)
                    }
                }).catch(
                res => {
                    console.log('error = ', res);
                    Toast.fail('调用合约失败', 2)
                }
            )
        }
        else if(this.getTokensById(pool.quoteToken).name === 'MDC'){
            window.MDCExtension.contract().at(contractAddress).then(functions => functions.invest(pool.baseToken, pool.quoteToken, this.toSun(pool.baseToken, this.state.baseAmount),
                this.toSun(pool.quoteToken, this.state.quoteAmount), 1).send({callValue:window.MDCExtension.toSun(this.state.quoteAmount)}))
                .then(res => {
                    console.log('res', res);
                    if (res) {
                        this.checkHash(res);
                    } else {
                        Toast.fail('调用合约失败', 2)
                    }
                }).catch(
                res => {
                    console.log('error = ', res);
                    Toast.fail('调用合约失败', 2)
                }
            )
        }
        else {

            let functions = await get20Contract(this.getTokensById(pool.baseToken).contractAddress);

            functions.approve(contractAddress, this.toSun(pool.baseToken, this.state.baseAmount)).send().then(res => {
                this.getApproveResult(res);
            }).catch(
                res => {
                    let err = extensionErr(res);
                    Toast.fail(err, 2, () => {
                    }, false);
                });


            // await get20Contract(this.getTokensById(pool.baseToken).contractAddress, (functions) => {
            //     console.log('functions', functions);
            //     functions.approve(contractAddress, this.toSun(pool.baseToken, this.state.baseAmount)).send().then(res => {
            //         this.getApproveResult(res);
            //     }).catch(
            //         res => {
            //             let err = extensionErr(res);
            //             Toast.fail(err, 2, () => {
            //             }, false);
            //         });
            // });
        }
    }

    toSun(id, amount){
       let token = this.getTokensById(id);

       return  new BigNumber(amount).times(10**token.decimal).toFixed(0);
    }

    invest(){

        const {pool} = this.props;

        window.MDCExtension.contract().at(contractAddress).then(functions => functions.invest(pool.baseToken, pool.quoteToken, this.toSun(pool.baseToken, this.state.baseAmount),
            this.toSun(pool.quoteToken, this.state.quoteAmount), 1).send())
            .then(res => {
                console.log('res', res);
                if (res) {
                    this.checkHash(res);
                } else {
                    Toast.fail('调用合约失败', 2)
                }
            }).catch(
            res => {
                console.log('error = ', res);
                Toast.fail('调用合约失败', 2)
            }
        )
    }

     checkHash(hash) {
        window.MDCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.success('添加流动性请求已提交，请等待区块链进行处理');
                this.props.onClose();
            } else {
                Toast.fail('调用合约失败', 2)
            }
        });
    }

    render() {
        const { visible, onClose, pool} = this.props;


        let token1 = this.getTokensById(pool.baseToken);
        let token2 = this.getTokensById(pool.quoteToken);
        let quantity = new BigNumber(this.getShareById(pool.id));
        let baseQuantity = new BigNumber(pool.baseQuantity);
        let quoteQuantity = new BigNumber(pool.quoteQuantity);
        let total = new BigNumber(pool.totalQuantity);
        let ratio = quoteQuantity.div(baseQuantity);
        let proportion = quantity.div(baseQuantity).div(quoteQuantity).times(100);

        let baseAmount = new BigNumber(this.state.baseAmount);
        let quoteAmount = new BigNumber(this.state.quoteAmount);

        let tmp = baseAmount.times(quoteAmount).squareRoot().plus(quantity);
        let total2 = total.plus(tmp);
        let tmp2 = tmp.div(total2).times(100);

        // let total = new BigNumber(pool.totalQuantity);

        let disable = !this.state.baseAmount || Number(this.state.baseAmount) === 0 || !this.state.quoteAmount || Number(this.state.quoteAmount) === 0 || this.state.quoteAmountErr || this.state.baseAmountErr;

        return (
            <div>
                <Modal
                    visible={this.state.modal3}
                    transparent
                    maskClosable={false}
                    onClose={()=>{this.setState({modal3:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                            MDC余额不足以支持手续费，请先充币哦~
                        </div>
                        <div onClick={()=>{this.setState({modal3:false})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            我已了解
                        </div>
                    </div>
                </Modal>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{onClose()}}
                    animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'swap-modal-pool'}>
                        <div className={'swap-modal-pool-header flex-between'} style={{padding:"0 5.33vw"}}>
                            {/*<img className={'btn-back'} alt="" src={require('../../../../images/swap/back.png')}/>*/}
                            <div className={'btn-back'}/>
                            <p style={{color:"#221814", fontSize:"4.53vw"}}>添加流动性份额</p>
                            <img onClick={()=>{onClose()}} className={'btn-close'} alt="" src={require('../../../../images/swap/close.png')}/>
                        </div>
                        <div style={{height:"1px", width:"94.67vw", backgroundColor:"#F3F7F7", marginLeft:"2.67vw"}}/>
                        <div>
                            <div className={'flex-between'} style={{width:'89.33vw', marginBottom:"-5vw", marginLeft:"5.33vw"}}>
                                <div className={'common-input-label'}>{this.getTokensById(pool.baseToken).name}数量</div>
                                <div className={'common-input-subLabel'}>可用余额：{this.getBalanceByTokenID(pool.baseToken)} {this.getTokensById(pool.baseToken).name}</div>
                            </div>
                            <div className={'flex-display'} style={{padding:"0 4vw"}}>
                                <Input
                                    width={'56.67vw'}
                                    // title={'您需要支付的数量' /*交易金额*/}
                                    tag={''}
                                    onBlur={()=>{this.updateRatio()}}
                                    value={this.state.baseAmount}
                                    // error={this.state.baseAmountErr}
                                    onChange={(val) => {
                                        this.checkInput(val, 0)
                                    }}
                                />
                                <div className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                                    <img className={'icon-xin'} alt="" src={token1.logo}/>
                                    <p className={'swap-p2'}>{this.getTokensById(pool.baseToken).name}</p>
                                    <div className={'icon-down-arrow'} />
                                </div>
                            </div>
                            {this.state.baseAmountErr !== "" ? <div className={'flex-end-col'} style={{marginTop:"-2.67vw", padding:"0 5.33vw 0 0"}}>
                                <div className={'swap-error'}>{this.state.baseAmountErr}</div>
                            </div> : null}
                        </div>
                        <div>
                            <div className={'flex-between'} style={{width:'89.33vw', marginBottom:"-5vw", marginLeft:"5.33vw"}}>
                                <div className={'common-input-label'}>{this.getTokensById(pool.quoteToken).name}数量</div>
                                <div className={'common-input-subLabel'}>可用余额：{this.getBalanceByTokenID(pool.quoteToken)} {this.getTokensById(pool.quoteToken).name}</div>
                            </div>
                            <div className={'flex-display'} style={{padding:"0 4vw"}}>
                                <Input
                                    width={'56.67vw'}
                                    // title={'您需要支付的数量' /*交易金额*/}
                                    onBlur={()=>{this.updateRatio()}}
                                    tag={''}
                                    value={this.state.quoteAmount}
                                    // error={this.state.quoteAmountErr}
                                    onChange={(val) => {
                                        this.checkInput(val, 1)
                                    }}
                                />
                                <div className={'swap-content-asset-choose flex-display'} style={{marginTop:"-1vw"}}>
                                    <img className={'icon-xin'} alt="" src={token2.logo}/>
                                    <p className={'swap-p2'}>{this.getTokensById(pool.quoteToken).name}</p>
                                    <div className={'icon-down-arrow'} />
                                </div>
                            </div>
                            {this.state.quoteAmountErr !== "" ? <div className={'flex-end-col'} style={{marginTop:"-2.67vw", padding:"0 5.33vw 0 0"}}>
                                <div className={'swap-error'}>{this.state.quoteAmountErr}</div>
                            </div> : null}
                        </div>
                        <div style={{padding:"0 5.33vw"}}>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>资金通证比例</p>
                                <p className={'swap-p6'}>{this.getTokensById(pool.baseToken).name}:{this.getTokensById(pool.quoteToken).name} = 1:{ratio.toFixed(4, 1)}</p>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>您当前的份额</p>
                                <p className={'swap-p6'}>{quantity.toFixed(4)}</p>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>您当前的份额占比</p>
                                <p className={'swap-p6'}>{proportion.toFixed(2)}%</p>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>添加成功后您的份额</p>
                                <p className={'swap-p6'}>{!this.state.baseAmount || !this.state.quoteAmount ||  Number(this.state.baseAmount) === 0 || Number(this.state.quoteAmount) === 0 ? '-' : tmp.toFixed(4)}</p>
                            </div>
                            <div className={'flex-between'}>
                                <p className={'swap-p5'}>添加成功后您的份额占比预估</p>
                                <p className={'swap-p6'}>{!this.state.baseAmount || !this.state.quoteAmount ||  Number(this.state.baseAmount) === 0 || Number(this.state.quoteAmount) === 0 ? '-' : tmp2.toFixed(2)}%</p>
                            </div>
                            <p className={'swap-p4'} style={{textAlign:"left", lineHeight:"6.13vw"}}>
                                若链上兑换价格发生变化，智能合约基于最新的资金池通证比例对您添加的份额进行处理，并会将剩余的数量返还给您。
                            </p>
                            <div onClick={disable ? ()=>{}:()=>{this.add()}} className={disable ? 'swap-btn-disable flex-center':'swap-btn flex-center'} style={{margin:"5.33vw 0", width:"89.33vw"}}>
                                <p className={'btn-text'}>加入资金池</p>
                            </div>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default connect(ModalPool);
