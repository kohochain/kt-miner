import React, { Component } from "react";
import {Modal, Slider, Toast} from 'antd-mobile';
import {Input} from "../index";
import intl from "react-intl-universal";
import connect from "../../../../store/connect";
import {extensionErr, inuputCheck} from "../../../../lib";
import BigNumber from "bignumber.js";
import {get20Contract} from "../../../../utils/mdc";

const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;

class ModalPoolExit extends Component {

    constructor(props){
        super(props);
        this.state = {
            ratio:0,
            ratioIndex:0,
            amount:0,
        }
    }

    getShareById(id){
        let share = this.props.redux.account.share;

        for(let i = 0;i < share.length; i++){
            if(share[i].poolId === id){
                return share[i].quantity;
            }
        }
        return 0;
    }

    getTokensById(id){

        let tokens = this.props.redux.tokenList;

        for(let i = 0;i < tokens.length; i++){
            if(tokens[i].id === id){
                return tokens[i];
            }
        }
        return {};
    };

    checkInput(val) {  // 0 数量 1 单价 2 最小交易数量 3 最大交易数量
        let value = inuputCheck(val,  4);
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {
        } else {
            value = value ? Number(value) : '';
        }
        this.setState({amount:value});

        const {pool} = this.props;

        let mst = this.getShareById(pool.id);

        if(new BigNumber(value).toNumber() > new BigNumber((mst)).toNumber())
        {
            this.setState({amountErr:"余额不足"});
        }
        else {

            let amount = value === "" ? 0:value;

            let total = new BigNumber((mst));

            this.setState({ratio:new BigNumber(amount).div(total).times(100).toFixed(0, 1)})
            this.setState({amountErr:""});
        }
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.MDCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.exit();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    exit(){

        const {pool} = this.props;

        window.MDCExtension.contract().at(contractAddress).then(functions => functions.withdraw(pool.baseToken, pool.quoteToken,
            this.toSun(pool.shareToken, this.state.amount)).send())
            .then(res => {
                console.log('res', res);
                if (res) {
                    this.checkHash(res);
                } else {
                    Toast.fail('调用合约失败', 2)
                }
            }).catch(
            res => {
                console.log('error = ', res);
                Toast.fail('调用合约失败', 2)
            }
        )
    }

    async withdraw(){

        if(this.props.redux.balance.mdc === 0)
        {
            this.setState({modal3:true});
            return ;
        }

        Toast.loading(intl.get('WAITING'), 0);

        const {pool} = this.props;


        let functions = await get20Contract(this.getTokensById(pool.shareToken).contractAddress);

        functions.approve(contractAddress, this.toSun(pool.shareToken, this.state.amount)).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });


        // await get20Contract(this.getTokensById(pool.shareToken).contractAddress, (functions) => {
        //     console.log('functions', functions);
        //     functions.approve(contractAddress, this.toSun(pool.shareToken, this.state.amount)).send().then(res => {
        //         this.getApproveResult(res);
        //     }).catch(
        //         res => {
        //             let err = extensionErr(res);
        //             Toast.fail(err, 2, () => {
        //             }, false);
        //         });
        // });
    }

    checkHash(hash) {
        window.MDCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.success('退出流动性请求已提交，请等待区块链进行处理');
                this.props.onClose();
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    toSun(id, amount){
        let token = this.getTokensById(id);

        return  new BigNumber(amount).times(10**token.decimal).toFixed(0);
    }

    render() {
        const { visible, onClose, pool} = this.props;

        let mst = new BigNumber(this.getShareById(pool.id));

        let baseQuantity = new BigNumber(pool.baseQuantity);
        let quoteQuantity = new BigNumber(pool.quoteQuantity);
        let ratio = quoteQuantity.div(baseQuantity);
        let proportion = mst.div(baseQuantity).div(quoteQuantity).times(100);

        let total = new BigNumber(pool.totalQuantity);

        let token1 = this.getTokensById(pool.baseToken);
        let token2 = this.getTokensById(pool.quoteToken);
        let token3 = this.getTokensById(pool.shareToken);
        let fee = pool.contractFee;

        let baseAmount = (new BigNumber(this.state.amount === "" ? 0 : this.state.amount).div(total)).times(baseQuantity);
        let quoteAmount = (new BigNumber(this.state.amount === "" ? 0 : this.state.amount).div(total)).times(quoteQuantity);

        let err = quoteAmount.toFixed(2, 1) < Number(fee);

        let disable = !this.state.amount || Number(this.state.amount) === 0 || this.state.amountErr || err;

        return (
            <div>
                <Modal
                    visible={this.state.modal3}
                    transparent
                    maskClosable={false}
                    onClose={()=>{this.setState({modal3:false})}}
                    // footer={[{ text: 'Ok', onPress: () => { console.log('ok'); this.onClose('modal1')(); } }]}
                >
                    <div className={'flex-center-col'}>
                        <div style={{ color:"#221814", fontSize:"4vw", lineHeight:"6.4vw"}}>
                            MDC余额不足以支持手续费，请先充币哦~
                        </div>
                        <div onClick={()=>{this.setState({modal3:false})}} style={{width:"60vw", height:"9.33vw", backgroundColor:"#FD8245", borderRadius:"2.13vw", lineHeight:"9.33vw", textAlign:"center",
                            color:"white", fontSize:"4vw", marginTop:"6.53vw"}}>
                            我已了解
                        </div>
                    </div>
                </Modal>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{onClose()}}
                    animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'swap-modal-pool'}>
                        <div className={'swap-modal-pool-header flex-between'} style={{padding:"0 5.33vw"}}>
                            <div className={'btn-back'} />
                            <p style={{color:"#221814", fontSize:"4.53vw"}}>退出流动性份额</p>
                            <img onClick={()=>{onClose()}} className={'btn-close'} alt="" src={require('../../../../images/swap/close.png')}/>
                        </div>
                        <div style={{height:"1px", width:"94.67vw", backgroundColor:"#F3F7F7", marginLeft:"2.67vw"}}/>
                        <div className={'flex-between'} style={{width:'89.33vw', marginBottom:"-5vw", marginLeft:"5.33vw"}}>
                            <div className={'common-input-label'}>请输入您想要退出的份额数量</div>
                        </div>
                        <Input
                            width={'84vw'}
                            // title={'您需要支付的数量' /*交易金额*/}
                            subTitle={'可用余额：XXX.XXXX MDC'}
                            // tag={token3.name}
                            value={this.state.amount}
                            error={this.state.amountErr}
                            onChange={(val) => {
                                this.checkInput(val)
                            }}
                        />
                        <div className={'flex-center'} style={{position:"relative", marginTop:"5.33vw"}}>
                            <p className={'slider-dot'}/>
                            <div style={{position:"absolute", left:parseInt(this.state.ratio * 0.873 + 1) + "%", top:"-8vw"}}>
                                <div className={'slider-pop'}>
                                    <p style={{fontSize:"3.2vw", color:"white"}}>
                                        {this.state.ratio + '%'}
                                    </p>
                                </div>
                                <p className={'triangle-down'} />
                            </div>
                            <Slider style={{width:"87.2vw"}}
                                    value={this.state.ratio}
                                    max={100}
                                    trackStyle={{height:"2px", backgroundColor:"#FCC9AE"}}
                                    railStyle={{height:"2px", backgroundColor:"#FCC9AE"}}
                                    handleStyle={{
                                        backgroundColor:"#FF700E",
                                        width:'4.27vw',
                                        height:"4.27vw",
                                        borderRadius:"2.135vw"
                                    }}
                                    onChange={(value)=>{
                                        this.setState({ratio:value, amount: mst.times(new BigNumber(value).div(100)).toFixed(4, 1)});
                                    }}
                            />
                            <p className={'slider-dot'} style={{marginLeft:"-1vw"}}/>
                        </div>
                        <div className={'flex-between'} style={{padding:"0 5.33vw"}}>
                            <div onClick={()=>{this.setState({ratio:25, amount: mst.times(new BigNumber(25).div(100)).toFixed(4, 1)})}} className={'modal-subRatio'}>
                                <div className={'text'}>25%</div>
                            </div>
                            <div onClick={()=>{this.setState({ratio:50, amount: mst.times(new BigNumber(50).div(100)).toFixed(4, 1)})}} className={'modal-subRatio'}>
                                <div className={'text'}>50%</div>
                            </div>
                            <div onClick={()=>{this.setState({ratio:75, amount: mst.times(new BigNumber(75).div(100)).toFixed(4, 1)})}} className={'modal-subRatio'}>
                                <div className={'text'}>75%</div>
                            </div>
                            <div onClick={()=>{this.setState({ratio:100, amount: mst.toFixed(4,1)})}} className={'modal-subRatio'}>
                                <div className={'text'}>100%</div>
                            </div>
                        </div>
                        <img style={{width:'4.4vw', height:"5.73vw", marginTop:"5.33vw"}} alt="" src={require('../../../../images/swap/exchange-2.png')}/>
                        <div className={'flex-between'} style={{padding:"0 5.33vw", position:"relative"}}>
                            <div className={'swap-output flex-between'}>
                                <p className={'swap-p4'}>
                                    {baseAmount.toFixed(4, 1)}
                                </p>
                                <div className={'flex-display'}>
                                    <img style={{width:"5.87vw", height:"5.87vw", borderRadius:"50%", border: "#fff0e6 2px solid"}} alt="" src={token1.logo}/>
                                    <p className={'swap-p4'} style={{marginLeft:"1.33vw"}}>
                                        {token1.name}
                                    </p>
                                </div>
                            </div>
                            <p style={{fontSize:'5.33vw', color:"#C1A59A"}}>
                                +
                            </p>
                            <div className={'swap-output flex-between'}>
                                <p className={'swap-p4'}>
                                    {quoteAmount.toFixed(4, 1)}
                                </p>
                                <div className={'flex-display'}>
                                    <img style={{width:"5.87vw", height:"5.87vw", borderRadius:"50%", border: "#fff0e6 2px solid"}} alt="" src={token2.logo}/>
                                    <p className={'swap-p4'} style={{marginLeft:"1.33vw"}}>
                                        {token2.name}
                                    </p>
                                </div>
                            </div>
                            {/*<p className={'swap-error'}>退出数量不得低于合约服务费</p>*/}
                        </div>
                        {err ? <div className={'flex-end-col'} style={{marginTop:"-2.67vw", padding:"0 5.33vw 0 0"}}>
                            <div className={'swap-error'}>退出数量不得低于合约服务费</div>
                        </div> : null}
                        <div style={{padding:"0 5.33vw"}}>
                            <div className={'flex-between'} style={{height:"8vw"}}>
                                <p className={'swap-p5'}>
                                    个人资金池份额
                                </p>
                                <p className={'swap-p6'}>
                                    {mst.toFixed(4, 1)}
                                </p>
                            </div>
                            <div className={'flex-between'} style={{height:"8vw"}}>
                                <p className={'swap-p5'}>
                                    资金池通证比例
                                </p>
                                <p className={'swap-p6'}>
                                    {token1.name}：{token2.name}=1：{ratio.toFixed(4, 1)}
                                </p>
                            </div>
                            <div className={'flex-between'} style={{height:"8vw"}}>
                                <p className={'swap-p5'}>
                                    合约服务费
                                </p>
                                <p className={'swap-p6'}>
                                    {fee} {token2.name}
                                </p>
                            </div>
                            <p className={'swap-p6'} style={{lineHeight:"6.13vw", textAlign:"left"}}>
                                因资金池随时可能产生交易、而导致通证比例发生变化，故预估退出数量仅作参考，请以实际到手数量为准；
                            </p>
                            <p className={'swap-p6'} style={{lineHeight:"6.13vw", textAlign:"left"}}>
                                系统将从您的到手数量中收取合约服务费。
                            </p>
                            <div onClick={disable ? ()=>{}:()=>{this.withdraw()}} className={disable ? 'swap-btn-disable flex-center' : 'swap-btn flex-center'} style={{margin:"5.33vw 0", width:"89.33vw"}}>
                                <p className={'btn-text'}>退出资金池</p>
                            </div>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default connect(ModalPoolExit);
