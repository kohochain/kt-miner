import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import {Input} from "../index";
import intl from "react-intl-universal";
import connect from "../../../../store/connect";

class ModalPoolList extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    getTokensById(id){

        let tokens = this.props.redux.tokenList;

        for(let i = 0;i < tokens.length; i++){
            if(tokens[i].id === id){
                return tokens[i];
            }
        }
        return {};
    };

    render() {
        const { visible, onClose, poolList, onSelect} = this.props;
        return (
            <div>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{onClose()}}
                    animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'swap-modal-pool'} style={{maxHeight:"161vw"}}>
                        <div className={'swap-modal-pool-header flex-between'} style={{padding:"0 5.33vw"}}>
                            <div className={'btn-close'}/>
                            <p style={{color:"#221814", fontSize:"4.53vw"}}>请选择资金池</p>
                            <img onClick={()=>{onClose()}} className={'btn-close'} alt="" src={require('../../../../images/swap/close.png')}/>
                        </div>
                        <div style={{height:"1px", width:"94.67vw", backgroundColor:"#F3F7F7", marginLeft:"2.67vw"}}/>
                        <div style={{marginBottom:"5.33vw"}}>
                            {poolList.map((item, index) => {
                                return (
                                    <div onClick={()=>{onSelect(item.id)}} className={'flex-center'} style={{height:"16.8vw"}}>
                                        <img style={{width:"8.8vw", height:"8.8vw", borderRadius:"50%", border: "#fff0e6 2px solid", marginRight:"-2.67vw", zIndex:2}} alt="" src={this.getTokensById(item.baseToken).logo}/>
                                        <img style={{width:"8.8vw", height:"8.8vw", borderRadius:"50%", border: "#fff0e6 2px solid", marginRight:"2.67vw"}} alt="" src={this.getTokensById(item.quoteToken).logo}/>
                                        <div style={{color:"#221814", fontSize:"4vw"}}>{this.getTokensById(item.baseToken).name}/{this.getTokensById(item.quoteToken).name}</div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default connect(ModalPoolList);
