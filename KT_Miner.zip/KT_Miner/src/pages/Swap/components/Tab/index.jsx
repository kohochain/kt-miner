import Tab from './tab';

export default Tab;