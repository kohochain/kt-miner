import React, { Component } from "react";

class Input extends Component {
    render() {
        const { value, onChange, title, tag, disabled, width, error, placeholder, subTitle, onBlur, green, balance} = this.props;
        return (
            <div>
                <div className={'common-input-label'}>{title}</div>
                <div className="common-input">
                    {tag ? <div className={'common-input-tag'}>{tag}</div> : null}
                    <input
                        style={{borderStyle: `${disabled ? 'dotted' : 'solid'}`, width: `${width ? width : '76vw'}` }}
                        onChange={(value) => {onChange(value.target.value)}}
                        value={value}
                        onBlur={onBlur ? ()=>{onBlur()} : ()=>{}}
                        placeholder={placeholder || ''}
                        type={'text'}
                        disabled={disabled}
                    />
                    {
                        balance ? <div className={'common-input-label'} style={{textAlign:"right"}}>{balance}</div>
                            :
                            null
                    }
                    {
                        error ?
                        <div className={'common-input-err flex-display'}>
                            <img style={{width:"4vw", height:"4vw", marginRight:"1.2vw"}} src={require('../../../../images/resonance/error.png')}/>
                            {error}
                        </div>
                        :
                        <div style={{height: '5vw'}} />
                    }
                </div>
            </div>
        );
    }
}

export default Input;
