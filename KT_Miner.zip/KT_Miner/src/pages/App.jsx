import React, {Component} from "react";
import {HashRouter as Router, Route} from 'react-router-dom';
import {LanguageContext} from './languageContext';
import setLanguage from './setLanguage';

import MinerPoly from './Miner/Poly'
import MinerPower from './Miner/Power'
import MinerAssessment from "./Miner/Assessment";
import MinerStatic from "./Miner/Static";
import MinerGroup from "./Miner/Group";
import MinerStudy from "./Miner/Study";
import MinerMortgageReward from "./Miner/MortgageReward"
import MinerSubscription from "./Miner/Subscription";
import MinerPool from "./Miner/Pool";

import Kt from './Kt'

import {getAddress} from '../utils/mdc';
import connect from '../store/connect';

class App extends Component {
	constructor(props) {
		super(props);

		this.state = {
			init: false,
			language: 'zh',
		};

		this.setLanguage = this.setLanguage.bind(this);
	}

	componentDidMount() {
		this.freshBalance();
		// this.setDevice();
		this.loadLocales();
		this.freshBalance();
	}

	setLanguage(currentLocale) {
		localStorage.setItem('lang', currentLocale);
		setLanguage(currentLocale).then(() => {
			this.setState({init: true, language: currentLocale});
		});
	}

	loadLocales() {
		let currentLocale = localStorage.getItem('lang') || 'zh';
		const {href} = window.location;
		if (href.indexOf('?') > -1) {
			const params = href.split('?')[1].split('#')[0];

			const paramList = params.split('&');

			paramList.forEach((item) => {
				const [key, value] = item.split('=');
				if (key === 'lang') {
					currentLocale = value;
				}
			});
		}
		if (['zh', 'en', 'ja', 'ko'].indexOf(currentLocale) === -1) currentLocale = 'zh';
		this.setLanguage(currentLocale);
	}

	setDevice() {
		const that = this;
		document.addEventListener("message", function handler(e) {
			console.log(e)
			if (e && e.data) {
				let obj = JSON.parse(e.data);
				console.log(obj.deviceId);
				that.props.setDevice(obj.deviceId);
			}
		})
	}

	async freshBalance() {
		if (getAddress()) {
			this.props.setAddress(getAddress());
			setTimeout(() => {
				if (this.props.redux.address !== getAddress()) {
					window.location.reload();
				}
				this.freshBalance();
			}, 10000);
			await this.props.updateBalance();
		} else {
			setTimeout(() => this.freshBalance(), 1000)
		}
	}

	render() {
		return (
			<LanguageContext.Provider
				value={{
					language: this.state.language,
					setLanguage: this.setLanguage,
				}}
			>
				<div className="full">
					<Router>
						<Route exact path="/" component={Kt}/>
						<Route exact path='/power' component={MinerPower}/>
						<Route exact path='/assessment' component={MinerAssessment}/>
						<Route exact path='/static' component={MinerStatic}/>
						<Route exact path='/group' component={MinerGroup}/>
						<Route exact path='/study' component={MinerStudy}/>
						<Route exact path='/mortgage' component={MinerMortgageReward}/>
						<Route exact path='/subscription' component={MinerSubscription}/>
						<Route exact path='/pool' component={MinerPool}/>
						<Route exact path='/poly' component={MinerPoly} />
					</Router>
				</div>
			</LanguageContext.Provider>
		)
	}
}

export default connect(App);
