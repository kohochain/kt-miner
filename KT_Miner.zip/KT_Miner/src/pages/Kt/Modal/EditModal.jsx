import React, { Component } from "react";
import { Modal} from 'antd-mobile';

class EditModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    render() {
        const { visible, onClose, commit, data} = this.props;

        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <img src={require('../../../images/kt/cancel.png')}  onClick={()=>{onClose()}} className={'miner-modal-cancel'} />
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>若您选择提高抵押倍数，则您需要补押对应数量的KHC；若您选择降低抵押倍数，您质押中未生效的KHC将会保持质押状态，您可选择手动解押全部质押中的KHC</div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                修改质押KHC的比例
                            </div>
                            <div className={'kt-poly-select'}>
                                质押{data.num}倍KHC
                            </div>
                        </div>
                        {data.value > 0 ? <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                修改倍数后还需质押KHC数量
                            </div>
                            <div className={'kt-p6'}>
                                {data.value} KHC
                            </div>
                        </div> : null}
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                修改倍数后加成比例
                            </div>
                            <div className={'kt-p6'}>
                                {this.getRate(data.rate)}
                            </div>
                        </div>
                        <div className={'kt-btn'} style={{marginTop:"8vw"}} onClick={()=>{commit(data.value > 0)}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default EditModal;
