import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class ReFreezeModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, amount, commit} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <img src={require('../../../images/kt/cancel.png')}  onClick={()=>{onClose()}} className={'miner-modal-cancel'} />
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>正在参与KT算力挖矿续押，续押仅续押领取收益中＞0的部分，剩余部分将保持待领取状态。</div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                续押数量
                            </div>
                            <div className={'kt-p6'}>
                                {Math.floor(amount)} KT
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                剩余数量
                            </div>
                            <div className={'kt-p6'}>
                                {parseFloat(amount - Math.floor(amount)).toFixed(4)} KT
                            </div>
                        </div>
                        <div className={'kt-btn'} style={{marginTop:"8vw"}} onClick={()=>{commit()}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default ReFreezeModal;
