import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";
import {Input} from "../../Swap/components";

class UnfreezeModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, amount, commit} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'miner-modal'}>
                    <div className={'miner-modal-header flex-between'}>
                        <img src={require('../../../images/kt/cancel.png')}  onClick={()=>{onClose()}} className={'miner-modal-cancel'} />
                        <div className={'miner-modal-title'}>安全验证</div>
                        <div className={'miner-modal-right'}>取消</div>
                    </div>
                    <div style={{padding:"5.33vw"}}>
                        <div className={'miner-p9'} style={{textAlign:"left"}}>请注意：正在进行抵押解押。确认解押后算力立即减少且解押的KHC将在T+3日后的24:00:00全额到账！
                            解押为链上交易，需要收取极少的KHC作为合约服务费。</div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                解押数量
                            </div>
                            <div className={'flex-display'}>
                                <div className={'miner-modal-input'}>
                                    {amount}
                                </div>
                                <div className={'kt-p6'} style={{marginLeft:"2.4vw"}}>
                                    KT
                                </div>
                            </div>
                        </div>
                        <div className={'kt-btn'} style={{marginTop:"8vw"}} onClick={()=>{commit()}}>
                            确认
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default UnfreezeModal;
