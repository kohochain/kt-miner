import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class PowerRuleModal extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose} = this.props;

        const rows = ["用户自身往下发展的无限代团队中，根据大区抵押和小区抵押两个考核标准，会员可分为1星 - 6星会员。", "大区，为用户下级无限代会员中抵押KT总量最大的一条会员线路。",
        "小区，即为下级除大区线路外的所有下级会员。", "成为星级会员的会员即可享受KT全球分红算力。", "全球分红算力=KHC平台所有会员的静态算力*48%（包含时间加成系数和KHC聚合算力加成系数）。",
        "各星级分配了不同比例的分红算力，同级会员均分。", "具体细则如下：（抵押数量单位均为KT）"];

        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width: "100vw", height: "100vh"}}>
                    <div className={'flex-center-col miner-toast'}>
                        <div style={{color: "#8E9594",
                            fontSize: "4.27vw"}}>全球算力分红说明</div>
                        <div style={{maxHeight:"60vh", overflow:"auto"}}>
                            {rows.map((item, index)=> {
                                return <div key={index} className={'miner-toast-text'}>
                                    {rows[index]}
                                </div>
                            })}
                            <div style={{width:"68vw", borderRadius:"1.33vw", marginTop:"5.33vw", border:".27vw #DFDFDF solid"}}>
                                <div className={'flex-display'} style={{border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                    <div style={{width:"10.67vw", height:"22.67vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                        <div style={{color:"#8F8F8F", fontSize:"3.2vw", textAlign:"center", lineHeight:"22.67vw"}}>星级</div>
                                    </div>
                                    <div className={'flex-center-col'} style={{width:"18.4vw", height:"22.67vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                        <div style={{color:"#8F8F8F", fontSize:"3.2vw", textAlign:"center"}}>条件1:大区抵押数</div>
                                    </div>
                                    <div className={'flex-center-col'} style={{width:"18.67vw", height:"22.67vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                        <div style={{color:"#8F8F8F", fontSize:"3.2vw", textAlign:"center"}}>条件2:小区抵押数</div>
                                    </div>
                                    <div className={'flex-center-col'} style={{width:"20vw", height:"22.67vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                        <div style={{color:"#8F8F8F", fontSize:"3.2vw", textAlign:"center"}}>该星级分红
                                            算力占全网
                                            静态算力的
                                            比例</div>
                                    </div>
                                </div>
                                <div className={'flex-display'}>
                                    <div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>1星</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>2星</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>3星</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>4星</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>5星</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"10.67vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>6星</div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className={'flex-center-col'} style={{width:"18.13vw", border:"0 #DFDFDF solid", height:"51.62vw", borderRightWidth:"0.27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>大区抵押
                                                KT数量≥
                                                小区抵押
                                                KT总量的
                                                1/4KT</div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥1万</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥3万</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥12万</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥20万</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥40万</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"18.4vw", height:"8.27vw", border:"0 #DFDFDF solid", borderRightWidth:"0.27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>≥60万</div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>14 %</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>10 %</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>8 %</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>8 %</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid", borderBottomWidth:".27vw"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>6 %</div>
                                        </div>
                                        <div className={'flex-center-col'} style={{width:"19.73vw", height:"8.27vw", border:"0 #DFDFDF solid"}}>
                                            <div style={{color:"black", fontSize:"3.2vw", textAlign:"center"}}>2 %</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className={'kt-btn'} style={{marginTop: "8vw", width:"68vw"}} onClick={() => {
                            onClose()
                        }}>
                            知道了
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default PowerRuleModal;
