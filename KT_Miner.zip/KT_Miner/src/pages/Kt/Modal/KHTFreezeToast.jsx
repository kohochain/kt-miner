import React, { Component } from "react";
import { Modal} from 'antd-mobile';
import intl from "react-intl-universal";

class KHTFreezeToast extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    render() {
        const { visible, onClose, onRoute} = this.props;
        return (
            <Modal
                popup
                visible={visible}
                onClose={()=>{onClose()}}
                animationType="slide-up"
                // afterClose={() => { onClose() }}
            >
                <div className={'flex-center-col'} style={{width: "100vw", height: "100vh"}}>
                    <div className={'flex-center-col miner-toast'}>
                        <div style={{maxHeight:"60vh", overflow:"auto"}}>
                            抵押中的KT数量发生变化，您的质押聚合算力可能会受到影响，您可前往进行KHC的补充质押
                        </div>
                       <div className={'flex-between'} style={{marginTop: "8vw"}}>
                           <div className={'kt-btn'} style={{width:"30vw", marginRight:"5.33vw", backgroundColor:"white", border:".27vw #909093 solid", color:" #909093"}} onClick={() => {
                               onClose()
                           }}>
                               取消
                           </div>
                           <div className={'kt-btn'} style={{width:"30vw"}} onClick={() => {
                               onRoute()
                           }}>
                               补充质押
                           </div>
                       </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default KHTFreezeToast;
