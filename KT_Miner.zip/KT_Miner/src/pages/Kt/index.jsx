import React, {Component} from "react";
import net from '../../server';
import connect from '../../store/connect';
import {Popover, Toast, Modal} from 'antd-mobile';
import moment from 'moment';
import intl from "react-intl-universal";
import {Input} from "../Swap/components";
import {BigNumber} from "bignumber.js";
import {
    getCNCContract,
    getMiningContract,
    getPurchaseContract,
    getResonanceContract,
    getICSContract,
    isRegistered,
    signTimestamp
} from "../../utils/mdc";
import {extensionErr, inuputCheck} from "../../lib";
import MinerModal from "./Modal/MinerModal";
import UnfreezeModal from "./Modal/UnfreezeModal";
import RewardModal from "./Modal/RewardModal";
import checkValue from "../../utils/checkValue";
import copy from "copy-to-clipboard";
import ToastModal from "../Miner/Modal/ToastModal";
import ReFreezeModal from "./Modal/ReFreezeModal";
import KHTFreezeToast from "./Modal/KHTFreezeToast";


const miningContractAddress = process.env.REACT_APP_CNC_MINING_CONTRACT;

const imgs = {
    "copy":require('../../images/kt/copy.png'),
    "info":require('../../images/kt/info.png'),
    "info2":require('../../images/kt/info2.png'),
};

const row1 = ["当用户地址连续抵押KT达到一定天数时，即可获得时间系数加成。", "时间系数加成可放大用户的静态算力，加持在用户有效算力上。", "时间系数加成规则如下：",
 "连续抵押天数≥30天，时间系数加成30%；", "连续抵押天数≥50天，时间系数加成50%；", "连续抵押天数≥80天，时间系数加成80%；", "连续抵押天数≥100天，时间系数加成100%",
"用户解除抵押后激励系数立即归零，再次抵押则重新开始计算抵押天数。"];

class Index extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
            tab2:0,
            guaranteeAfter:0,
            amount:"",
            unfreezeTimeLabel:"-",
            pause:null
        }
    }

    componentDidMount(){
        this.login();
    }



    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {
            this.getData(1);
            this.timer = setInterval(() => {
                this.getData();
            }, 5000);
        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    async getData(type){

        const {address} = this.props.redux;

        net.getMinerAddressInfo({address:address}).then(res => {
            if(type){
                Toast.hide();
            }
            if(res.response_code === '00')
            {
                this.setState(res.content);
                if(type){
                    this.timer = setInterval(() => {
                        this.openTimes();
                    }, 1000);
                }
            }
            else {
                Toast.fail(res.response_msg);
            }
        });

        net.getMinerGlobalInfo({address:address}).then(res => {
            if(res.response_code === '00')
            {
                this.setState(res.content);
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    async getContract(){
        if(!this.contract){
            this.contract = await getMiningContract();
        }

        return this.contract;
    }

    getValue(value, number, mode)
    {
        return checkValue(value, number, mode ? 0 : mode);
    }

    getGuarantee(value){
        return checkValue(value, 0, 3);
    }

    getAfterGuarantee(){

        const {frozen, guaranteeRate, amount} = this.state;

        if(!guaranteeRate || amount === "")
            return "-";

        return new BigNumber(guaranteeRate).times(amount).plus(frozen).toNumber();
    }

    getRate(value){
        if(value === undefined || value === null)
            return "-";

        return parseFloat(value * 100).toFixed(1) + "%";
    }

    checkInput(val) {  // 0 数量 1 单价 2 最小交易数量 3 最大交易数量
        let value = inuputCheck(val,  4);
        let isInt = false;
        if (value[value.length - 1] === '.' || value[value.length - 1] === '0') {

        } else {
            value = value ? Number(value) : '';
        }

        if(parseInt(value) === Number(value))
            isInt = true;

        // const { balance, withdrawFee} = this.props;
        const {cnc} = this.props.redux.balance;

        const {frozenLimit, frozen, guaranteeLimit} = this.state;
        const remain = new BigNumber(frozenLimit).minus(frozen).toNumber();

        this.setState({amount:value});
        if ((Number(frozen) + Number(value)) < guaranteeLimit)
        {
            this.setState({amountErr:"最小抵押数量不能小于" + guaranteeLimit});
        }
        else if(!isInt)
        {
            this.setState({amountErr:"最小抵押单位不得小于1"});
        }
        else if(value > Number(cnc))
        {
            this.setState({amountErr:"KT余额不足"});
        }
        else if (value > remain)
        {
            this.setState({amountErr:"最大可抵押数量不足"});
        }
        else {
            this.setState({amountErr:""});
        }
    }

    async postFreeze(){

        Toast.loading(intl.get('WAITING'), 0);

        const params = await signTimestamp();

        net.postMineFreeze(params).then(res => {
            if(res.response_code === '00')
            {
                // this.setState(res.content);
                Toast.success('续押成功');
                this.getData();
                if(this.state.khtFrozen){
                    this.setState({khtToastVisible:true});
                }
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    openTimes(){

        const date = this.state.unfreezeTime;

        if(date === undefined || date === null)
        {
            this.setState({unfreezeTimeLabel:"-"});
            return;
        }

        let date3 = (date - moment().valueOf())/1000;   //时间差的毫秒数

        if(date3 < 0)
        {
            this.setState({unfreezeTimeLabel:"-"});
            clearTimeout(this.timer) && (this.timer = null);
            return;
        }

        let leave1= date3 %(24*3600);    //计算天数后剩余的毫秒数
        let hours= Math.floor(date3/(3600));
        //计算相差分钟数
        let leave2 = leave1 % (3600) ;       //计算小时数后剩余的毫秒数
        let minutes = Math.floor(leave2/(60));
        //计算相差秒数
        let leave3 = leave2 % (60) ;     //计算分钟数后剩余的毫秒数
        let seconds = Math.round(leave3);

        let label = (hours < 10 ? ("0" + hours) : hours) + ":" +  (minutes < 10 ? ("0" + minutes) : minutes) + ":" +  (seconds < 10 ? ("0" + seconds) : seconds);

        this.setState({unfreezeTimeLabel:label});
    }

    async miningCheck(){
        const {kht} = this.props.redux.balance;
        if(kht === 0)
        {
            Toast.fail('KHC余额为0，不足支付交易手续费');
            return;
        }

        let contract = await getCNCContract();

        Toast.loading('提交中', 0);

        contract.approve(miningContractAddress, window.KHCExtension.toSun(this.state.amount)).send().then(res => {
            this.getApproveResult(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async unfreeze(){
        const {kht} = this.props.redux.balance;
        if(kht === 0)
        {
            Toast.fail('KHC余额为0，不足支付交易手续费');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await this.getContract();

        // let fee = await contract.fee().call();

        // fee = window.KHCExtension.toDecimal(fee);

        contract.unfreeze(0).send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    async getReward(){
        const {kht} = this.props.redux.balance;
        if(kht === 0)
        {
            Toast.fail('KHC余额为0，不足支付交易手续费');
            return;
        }

        Toast.loading('提交中', 0);

        const contract = await this.getContract();

        contract.getReward().send().then(res => {
            this.checkHash(res);
        }).catch(
            res => {

                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    getApproveResult(res) {
        console.log('result.ret ------->', res);
        window.KHCExtension.trx.getTransaction(res).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.getApproveResult(res)
                }, 2000);
                return;
            }
            console.log('result.ret ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                this.mining();
            } else {
                Toast.fail(intl.get('APPROVE_FAIL'), 2)
            }
        }).catch(()=>{
            this.getApproveResult(res);
        })
    }

    async mining(){
        Toast.loading('提交中', 0);

        const contract = await this.getContract();
        contract.freeze(this.state.amount, 0).send().then(res => {
            this.checkHash(res, true);
        }).catch(
            res => {
                let err = extensionErr(res);
                Toast.fail(err, 2, () => {
                }, false);
            });
    }

    checkHash(hash, flag) {
        window.KHCExtension.trx.getTransaction(hash).then(result => {
            if (!result.ret) {
                setTimeout(() => {
                    this.checkHash(hash)
                }, 2000);
                return;
            }

            console.log('result.ret2 ------->', result);

            if (result.ret && result.ret[0]['contractRet'] === 'SUCCESS') {
                Toast.hide();
                Toast.success("操作成功，稍后查看");
                if(this.state.khtFrozen && flag){
                    this.setState({khtToastVisible:true});
                }
            } else {
                Toast.fail('调用合约失败', 2)
            }
        }).catch(()=>{
            this.checkHash(hash);
        });
    }

    getBurnReward(){
        const {leftMineReward, rewardBurnRate, cncPrice} = this.state;

        return new BigNumber(leftMineReward).times(rewardBurnRate).times(cncPrice).toFixed(4, 1);
    }

    getClick(button){
        net.getMineClick({button:button});
    }

    renderHeader(){

        const {kid} = this.state;

        return (
            <div className={'kt-miner-header flex-center'}>
                {kid ? <div className={'flex-between'} style={{padding:"0 8vw", width:"100%"}}>
                    <div className={'flex-display'}>
                        <div className={'kt-miner-header-p'}>
                            您的KID:
                        </div>
                        <div className={'kt-p2'}>
                            {kid}
                        </div>
                    </div>
                    <img onClick={()=>{
                        copy(kid || '-');
                        Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                    }} src={imgs['copy']} style={{width:"6.4vw", height:"6.4vw"}} />
                </div> : <div style={{padding:"0 8vw", width:"100%"}}>
                    <div className={'kt-miner-header-p'}>
                        您尚未激活KID
                    </div>
                    <div style={{marginTop:"1vw"}} className={'kt-miner-header-p'}>
                        激活KID 领取参与资格
                    </div>
                </div>}
            </div>
        )
    }

    renderTop(){

        const {tab} = this.state;

        return (
            <div style={{marginTop:"4vw"}}>
                <div className={'flex-display'}>
                    <div onClick={()=>{this.setState({tab:0})}} className={tab ? 'kt-miner-select-left-unselect':'kt-miner-select-left-select'}>
                        个人
                    </div>
                    <div onClick={()=>{this.setState({tab:1})}} className={tab ? 'kt-miner-select-right-select':'kt-miner-select-right-unselect'}>
                        全网
                    </div>
                </div>
                {tab === 1 ? <div className={'kt-miner-card flex-center-col'}>
                    <div className={'kt-miner-card-color1 flex-between'} style={{marginBottom:"2.67vw"}}>
                        <div className={'kt-p1'}>全网累计产矿</div>
                        <div className={'flex-end-s'}>
                            <div className={'kt-p2'}>{this.getValue(this.state.totalMined)}</div>
                            <div style={{marginLeft:"2vw"}} className={'kt-p1'}>KT</div>
                        </div>
                    </div>
                    <div className={'kt-miner-card-color2 flex-between'} style={{marginBottom:"2.67vw"}}>
                        <div className={'flex-display'}>
                            <div className={'kt-p1'}>今日预计全网可挖</div>
                            <img onClick={()=>{this.setState({totalVisible1:true})}} style={{width:"6.4vw", height:"6.4vw"}} src={imgs['info']}/>
                        </div>
                        <div className={'flex-end-s'}>
                            <div className={'kt-p2'}>{this.getValue(this.state.predictMine)}</div>
                            <div style={{marginLeft:"2vw"}} className={'kt-p1'}>KT</div>
                        </div>
                    </div>
                    <div className={'kt-miner-card-color3 flex-between'}>
                        <div className={'flex-display'}>
                            <div className={'kt-p1'}>今日全网有效算力</div>
                            <img onClick={()=>{this.setState({totalVisible2:true})}} style={{width:"6.4vw", height:"6.4vw"}} src={imgs['info']}/>
                        </div>
                        <div className={'kt-p2'}>{this.getGuarantee(this.state.totalEffectiveGuarantee)}</div>
                    </div>
                </div> : <div className={'kt-miner-card flex-center-col'}>
                    <div className={'kt-miner-card-color1 flex-between'} style={{marginBottom:"2.67vw"}}>
                        <div className={'kt-p1'}>个人累计挖矿</div>
                        <div className={'flex-end-s'}>
                            <div className={'kt-p2'}>{this.getValue(this.state.mineReward)}</div>
                            <div style={{marginLeft:"2vw"}} className={'kt-p1'}>KT</div>
                        </div>
                    </div>
                    <div className={'kt-miner-card-color2 flex-between'} style={{marginBottom:"2.67vw"}}>
                        <div className={'flex-display'}>
                            <div className={'kt-p1'}>个人今日预计可挖</div>
                            <img onClick={()=>{this.setState({userVisible1:true})}} style={{width:"6.4vw", height:"6.4vw"}} src={imgs['info']}/>
                        </div>
                        <div className={'flex-end-s'}>
                            <div className={'kt-p2'}>{this.getValue(this.state.userPredictMine)}</div>
                            <div style={{marginLeft:"2vw"}} className={'kt-p1'}>KT</div>
                        </div>
                    </div>
                    <div className={'kt-miner-card-color3 flex-between'}>
                        <div className={'flex-display'}>
                            <div className={'kt-p1'}>个人今日有效算力</div>
                            <img onClick={()=>{this.setState({userVisible2:true})}} style={{width:"6.4vw", height:"6.4vw"}} src={imgs['info']}/>
                        </div>
                        <div className={'kt-p2'}>{this.getGuarantee(this.state.effectiveGuarantee)}</div>
                    </div>
                </div>}
            </div>
        )
    }

    renderMid(){
        return (
            <div className={'kt-miner-card'} style={{marginTop:"4vw"}}>
                <div className={'kt-p3'}>算力详情</div>
                <div className={'flex-display'} style={{marginTop:"4.27vw"}}>
                    <div className={'kt-miner-card-gray1 flex-display-col'} style={{marginRight:"2.67vw"}}>
                        <div className={'kt-p4'} style={{marginTop:"4.53vw"}}>静态算力</div>
                        <div className={'kt-p3'} style={{marginTop:"1.87vw", marginBottom:"1.87vw"}}>{this.getGuarantee(this.state.frozenGuarantee)}</div>
                        <div onClick={()=>{this.props.history.push(`/static`)}} className={'kt-p5'}>查看详情</div>
                    </div>
                    <div className={'kt-miner-card-gray1 flex-display-col'} style={{marginRight:"2.67vw"}}>
                        <div className={'kt-p4'} style={{marginTop:"4.53vw"}}>时间加成算力</div>
                        <div className={'kt-p3'} style={{marginTop:"1.87vw"}}>{this.getGuarantee(this.state.timeGuarantee)}</div>
                        <img onClick={()=>{this.setState({timeVisible:true})}} style={{width:"6.4vw", height:"6.4vw"}} src={imgs['info2']}/>
                    </div>
                    <div className={'kt-miner-card-gray1 flex-display-col'}>
                        <div className={'kt-p4'} style={{marginTop:"4.53vw"}}>KHC聚合算力</div>
                        <div className={'kt-p3'} style={{marginTop:"1.87vw", marginBottom:"1.87vw"}}>{this.getRate(this.state.khtRate)}</div>
                        <div onClick={()=>{this.props.history.push(`/poly`)}} className={'kt-p5'}>立即抵押</div>
                    </div>
                </div>
                <div className={'flex-display'} style={{marginTop:"4.27vw"}}>
                    <div className={'kt-miner-card-gray2 flex-display-col'} style={{marginRight:"2.67vw"}}>
                        <div className={'kt-p4'} style={{marginTop:"4.53vw"}}>共识挖矿算力</div>
                        <div className={'kt-p3'} style={{marginTop:"1.87vw", marginBottom:"1.87vw"}}>{this.getGuarantee(this.state.groupGuarantee)}</div>
                        <div onClick={()=>{this.props.history.push(`/group`)}} className={'kt-p5'}>查看详情</div>
                    </div>
                    <div className={'kt-miner-card-gray2 flex-display-col'} style={{marginRight:"2.67vw"}}>
                        <div className={'kt-p4'} style={{marginTop:"4.53vw"}}>全球分红算力</div>
                        <div className={'kt-p3'} style={{marginTop:"1.87vw", marginBottom:"1.87vw"}}>{this.getGuarantee(this.state.globalGuarantee)}</div>
                        <div onClick={()=>{this.props.history.push(`/power`)}} className={'kt-p5'}>查看详情</div>
                    </div>
                </div>
            </div>
        )
    }

    renderBottom(){

        const {frozenLimit, frozen, tab2, amountErr, amount, kid, pause, leftMineReward, unfreezing} = this.state;
        const cnc = !frozenLimit ? "-" : new BigNumber(frozenLimit).minus(frozen).toNumber();

        let systemTime = false;

        if(Number(moment().format("HH")) === 23 && Number(moment().format("mm")) >= 50)
        {
            systemTime = true;
        }

        if(Number(moment().format("HH")) === 0 && Number(moment().format("mm")) <= 5)
        {
            systemTime = true;
        }

        const ContractPause = pause === 1;

        const MinerDisable = amountErr || !amount || amount === "" || !kid || systemTime || ContractPause;
        const unFreezeDisable = !frozen || ContractPause || systemTime || !kid;

        return (
            <div style={{marginTop:"4vw"}}>
                <div className={'flex-display'}>
                    <div onClick={()=>{this.setState({tab2:0})}} className={tab2 ? 'kt-miner-select-left-unselect':'kt-miner-select-left-select'}>
                        抵押
                    </div>
                    <div onClick={()=>{this.setState({tab2:1})}} className={tab2 ? 'kt-miner-select-right-select':'kt-miner-select-right-unselect'}>
                        解押
                    </div>
                </div>
                <div className={'kt-miner-card flex-display-col'}>
                    {leftMineReward ? <div className={'kt-miner-card-reward-bg flex-between'}>
                        <div className={'kt-p7'}>待领取抵押收益：{this.getValue(leftMineReward, 4,1)} KT</div>
                        <div className={'flex-display'}>
                            <div onClick={()=>{
                                if(Number(leftMineReward) >= 1)
                                {
                                    if(unfreezing)
                                    {
                                        Toast.fail('您当前有解押中的KT，解押完成后可继续参与抵押');
                                    }
                                    else {
                                        this.setState({refreezeVisible:true});
                                        this.getClick('refund');
                                    }
                                }
                                else {
                                    Toast.fail("奖励数量需要在1KT以上才可以进行续押哦")
                                }
                            }} className={'kt-miner-card-reward-bg-btn'}>续押</div>
                            <div onClick={()=>{
                                if(Number(leftMineReward) >= 1)
                                {
                                    this.setState({rewardVisible:true});
                                    this.getClick('getReward');
                                }
                                else {
                                    Toast.fail("奖励数量需要在1KT以上才可以领取哦")
                                }
                            }} className={'kt-miner-card-reward-bg-p'}>领取</div>
                        </div>
                    </div> : null}
                    {tab2 === 0 ? <div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                抵押数量
                            </div>
                            <div className={'flex-display'}>
                                <Input
                                    width={'48vw'}
                                    value={this.state.amount}
                                    error={this.state.amountErr}
                                    onChange={(val) => {
                                        this.checkInput(val)
                                    }}
                                />
                                <div className={'kt-p6'} style={{marginLeft:"2.4vw"}}>
                                    KT
                                </div>
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                当前静态算力
                            </div>
                            <div className={'kt-p6'}>
                                {this.getGuarantee(this.state.frozenGuarantee)}
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                当前连续抵押天数
                            </div>
                            <div onClick={()=>{this.props.history.push(`/static`)}} className={'kt-p5'}>查看详情</div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                抵押后静态算力
                            </div>
                            <div className={'kt-p6'}>
                                {this.getAfterGuarantee()}
                            </div>
                        </div>
                        <div className={MinerDisable ? 'kt-btn-disable' : 'kt-btn'} onClick={MinerDisable ? ()=>{} : ()=>{
                            if(unfreezing)
                            {
                                Toast.fail('您当前有解押中的KT，解押完成后可继续参与抵押');
                            }
                            else {
                                this.setState({minerVisible:true})
                            }
                        }}>
                            {ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间" :(kid ? "抵押": "请先激活KID"))}
                        </div>
                    </div> : <div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                抵押中数量
                            </div>
                            <div className={'kt-p6'}>
                                {this.getGuarantee(this.state.frozen)}
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                解押中数量
                            </div>
                            <div className={'kt-p6'}>
                                {this.getGuarantee(unfreezing)}
                            </div>
                        </div>
                        <div className={'flex-between'} style={{width:"100%", height:"13.33vw"}}>
                            <div className={'kt-p6'}>
                                解押倒计时
                            </div>
                            <div className={'kt-p6'}>
                                {this.state.unfreezeTimeLabel}
                            </div>
                        </div>
                        <div className={unFreezeDisable ? 'kt-btn-disable' : 'kt-btn'} onClick={unFreezeDisable ? ()=>{} : ()=>{this.setState({unfreezeVisible:true})}}>
                            {ContractPause ? "服务暂停中":(systemTime ? "23:55～00:05为系统结算时间" :(kid ? (frozen ? "解押":"暂无抵押中KT"): "请先激活KID"))}
                        </div>
                    </div>}
                </div>
            </div>)
    }

    render() {

        let {khtToastVisible, userVisible1, userVisible2, timeVisible, refreezeVisible, totalVisible1, totalVisible2, minerVisible, amount, unfreezeVisible, frozen, rewardVisible, leftMineReward, kid} = this.state;
        const {address, balance} = this.props.redux;

        return (
            //style={{overflow:"hidden"}}

            <div className="page kt">
                <MinerModal visible={minerVisible} onClose={()=>{this.setState({minerVisible:false})}}
                            amount={amount} commit={()=>{
                    this.setState({minerVisible:false});
                    this.miningCheck();
                }}
                />
                <UnfreezeModal visible={unfreezeVisible} onClose={()=>{this.setState({unfreezeVisible:false})}}
                               amount={frozen} commit={()=>{
                    this.setState({unfreezeVisible:false});
                    this.unfreeze();
                }}/>
                <RewardModal visible={rewardVisible} onClose={()=>{this.setState({rewardVisible:false})}}
                             amount={leftMineReward} commit={()=>{
                    this.setState({rewardVisible:false});
                    this.getReward();
                }}/>
                <ReFreezeModal visible={refreezeVisible} onClose={()=>{
                    this.getClick('cancel');
                    this.setState({refreezeVisible:false})
                }} amount={leftMineReward} commit={()=>{
                    this.setState({refreezeVisible:false});
                    this.postFreeze();
                }}/>
                <KHTFreezeToast visible={khtToastVisible}
                                onRoute={()=>{this.setState({khtToastVisible:false}); this.props.history.push(`/poly`)}}
                                onClose={()=>{this.setState({khtToastVisible:false})}} />
                <ToastModal visible={userVisible1} onClose={()=>{this.setState({userVisible1:false})}} title={""}
                            rows={["用户当前的有效算力/全网当前有效算力之和*今日"]}
                />
                <ToastModal visible={userVisible2} onClose={()=>{this.setState({userVisible2:false})}} title={""}
                            rows={["静态（1+时间系数+聚合系数）+动态"]}
                />
                <ToastModal visible={totalVisible1} onClose={()=>{this.setState({totalVisible1:false})}} title={""}
                            rows={["当日KT产矿量 * （全网用户抵押KT数量 / 当前KT总流通量），一个小时更新一次"]}
                />
                <ToastModal visible={totalVisible2} onClose={()=>{this.setState({totalVisible2:false})}} title={""}
                            rows={["全网用户有效算力的总和"]}
                />
                <ToastModal visible={timeVisible} onClose={()=>{this.setState({timeVisible:false})}} title={""}
                            rows={row1}
                />
                {this.renderHeader()}
                {this.renderTop()}
                {kid ? this.renderMid() : null}
                {this.renderBottom()}
            </div>
        );
    }
}

export default connect(Index);
