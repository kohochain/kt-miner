import msdtContractInfo from '../lib/msdtContract';
import contractInfo from '../lib/contractAddress';


let KHCExtension = window.KHCExtension;
let Contract = null;
const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;
const msdtContract = process.env.REACT_APP_USDT_CONTRACT;

const interval = setInterval(async () => {
    KHCExtension = window.KHCExtension;
    if (!KHCExtension) return;
    if (KHCExtension) {
        msdtContractInfo.contract_address = KHCExtension.address.toHex(msdtContract);
        contractInfo.contract_address = KHCExtension.address.toHex(contractAddress);
        clearInterval(interval);
        // await getContract();
    }
}, 1000);


export function getAddress() {
    if (KHCExtension && KHCExtension.defaultAddress) {
        return KHCExtension.defaultAddress.base58
    } else {
        return ''
    }
}

const getContract = async () => {
    if (Contract) return;
    try {
        // Contract = await KHCExtension.contract().at(contractAddress)
        Contract = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
    } catch (err) {
        await getContract()
    }
};

export function checkAddress() {
    if (!KHCExtension) {
        return { success: false, message: '请先安装 KHCExtension 插件' }
    } else if (!KHCExtension.defaultAddress) {
        return { success: false, message: '请先创建钱包或者解锁插件' }
    } else {
        return { success: true, address: KHCExtension.defaultAddress.base58 }
    }
}

export async function signTimestamp() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    const params = {
        timestamp,
        address: KHCExtension.defaultAddress.base58,
    };

    try {
        params.sign = await KHCExtension.trx.sign(signature);

        return params;
    } catch (e) {
        console.warn(e);
        return false;
    }
}

export async function getBalance() {
    const result = await KHCExtension.trx.getUnconfirmedAccount(KHCExtension.defaultAddress.base58);
    let balance = Number(KHCExtension.fromSun(result.balance));
    balance = (Math.floor(balance * 10000) / 10000).toFixed(4)
    return Number(balance)
}

export async function get20Balance() {
    const result = await KHCExtension.contract().at(msdtContract);
    return result.balanceOf(KHCExtension.defaultAddress.base58).call()
}

export async function get20BalanceResult() {
    let result = await KHCExtension.contract(msdtContractInfo.abi.entrys, msdtContractInfo.contract_address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call()
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromSun(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)
    return balance_20
}

export async function getFee(){
    let result = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
    let  fee = await result.cancelFee().call();
    fee = KHCExtension.toDecimal(fee);
    return KHCExtension.fromSun(fee);
}

export async function transfer(amount) {
    return KHCExtension.trx.sendTransaction(contractAddress, KHCExtension.toSun(amount));
}

export async function makeOrder(symbol1, symbol2, amount, price, min, max) {  // symbol1 给钱的币种 symbol2 要买的币种id
    if (!Contract) return false;

    return Contract.makeOrder(symbol1, symbol2, amount, amount, min, max).send();
}

export async function takeOrder(orderId, symbolId, amount) { // symbol 给钱的币种
    if (!Contract) return false;

    return Contract.takeOrder(orderId, symbolId, amount).send();
}

export async function cancelOrder(orderId) {
    if (!Contract) return false;
    return Contract.cancelOrder(orderId).send();
}


