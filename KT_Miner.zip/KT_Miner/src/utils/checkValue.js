import BigNumber from "bignumber.js";

export default function (value, number, mode) {
    if(value === undefined || value === null || isNaN(value) || value === 'NaN')
    {
        return "-"
    }

    if(mode === 2)
    {
        return value;
    }

    return new BigNumber(value).toFixed(number === undefined || number === null ? 4 : number, mode);
}
