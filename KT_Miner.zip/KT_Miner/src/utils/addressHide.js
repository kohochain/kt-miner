export default function addressHide(address) {
    if(!address || address === "")
        return "";

    if(address.length < 5) {
        return address;
    }

    let k1 = address.substr(0,4);
    let k2 = address.substr(address.length - 3, 3);

    return k1 + "..." + k2;
}
