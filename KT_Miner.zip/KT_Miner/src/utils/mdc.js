import msdtContractInfo from '../lib/msdtContract';
import purchaseContractInfo from "../lib/purchaseContract";
import contractInfo from '../lib/contractAddress';
import miningContractInfo from "../lib/miningContract";
import resonanceContractInfo from "../lib/resonanceContract";
import accountAddressInfo from "../lib/accountAddress";
import registerAddressInfo from "../lib/registerAddress";
import { Toast } from "antd-mobile";
import {extensionErr} from "../lib";


let KHCExtension = window.KHCExtension;
let Contract = null;
const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS;
const msdtContract = process.env.REACT_APP_USDT_CONTRACT;
const icsContract = process.env.REACT_APP_ICS_CONTRACT;
const cncContract = process.env.REACT_APP_CNC_CONTRACT;
const purchaseContract = process.env.REACT_APP_PURCHASE_CONTRACT;
const miningContractAddress = process.env.REACT_APP_CNC_MINING_CONTRACT;
const resonanceContractAddress = process.env.REACT_APP_CNC_RESONANCE_CONTRACT;
const accountAddress = process.env.REACT_APP_ACCOUNT_ADDRESS;
const registerAddress = process.env.REACT_APP_REGISTER_ADDRESS;

let accountContract = null;
let registerContract = null;

const interval = setInterval(async () => {
    KHCExtension = window.KHCExtension;
    if (!KHCExtension) return;
    if (KHCExtension) {
        msdtContractInfo.contract_address = KHCExtension.address.toHex(msdtContract);
        contractInfo.contract_address = KHCExtension.address.toHex(contractAddress);
        miningContractInfo.contract_address = KHCExtension.address.toHex(miningContractAddress);
        resonanceContractInfo.contract_address = KHCExtension.address.toHex(resonanceContractAddress);
        accountAddressInfo.contract_address = KHCExtension.address.toHex(accountAddress);
        registerAddressInfo.contract_address = KHCExtension.address.toHex(registerAddress);

        await getContract2(accountAddressInfo, (contract) => { accountContract = contract });
        await getContract2(registerAddressInfo, (contract) => { registerContract = contract });

        clearInterval(interval);
        // await getContract();
    }
}, 1000);


export function getAddress() {
    if (KHCExtension && KHCExtension.defaultAddress) {
        return KHCExtension.defaultAddress.base58
    } else {
        return ''
    }
}

const getContract = async () => {
    if (Contract) return;
    try {
        // Contract = await KHCExtension.contract().at(contractAddress)
        Contract = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
    } catch (err) {
        await getContract()
    }
};

const getContract2 = async (contractInfo, callback) => {
    try {
        let contract = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
        // let contract = await KHCExtension.contract().at(address)
        callback(contract);
    } catch (err) {
        console.log(err)
        await getContract2(contractInfo, callback);
    }
};

export async function activeAccount(inviteCode, deviceId) {
    if (!accountContract) return;
    try {
        return await accountContract.campaignNode(inviteCode, deviceId).send();
    } catch (e) {
        Toast.fail(extensionErr(e), 2);
        return false;
    }
}

export async function register(inviteCode) {
    if(!registerContract) return;
    try {
        // let registerContract = await KHCExtension.contract().at(registerAddress)
        let registerContract = await KHCExtension.contract(
            registerAddressInfo.abi.entrys,
            registerAddressInfo.contract_address
        );
        // let registerContract = await KHCExtension.contract(registerAddressInfo.abi.entrys, registerAddressInfo.contract_address);
        return await registerContract.register(inviteCode).send();
    } catch (e) {
        Toast.fail(extensionErr(e), 2);
        return false;
    }
}

export async function getResult(hash) {
    try {
        // return await KHCExtension.mdc.getTransaction(hash);
        return await KHCExtension.trx.getTransaction(hash);
    } catch (e) {
        Toast.fail(extensionErr(e), 2)
        return false;
    }
}

export async function approveIcs(amount, address) {
    if (!icsContract) return;
    KHCExtension = await getExtension();

    const contract = await getICSContract();

    try {
        return await contract.approve(address || accountAddress, KHCExtension.toSun(amount)).send();
    } catch (e) {
        Toast.fail(extensionErr(e), 2)
        return false;
    }
}

export async function getIcsFee() {
    if (!icsContract) return;
    KHCExtension = await getExtension();

    // const contract = await getICSContract();

    let accountContract = await KHCExtension.contract(
        accountAddressInfo.abi.entrys,
        accountAddressInfo.contract_address
    );

    try {
        return await accountContract.campaignFee().call();
    } catch (e) {
        Toast.fail(extensionErr(e), 2)
        return false;
    }
}

export async function isRegistered() {
    if (!registerContract) return;

    let contract = await KHCExtension.contract(
        registerAddressInfo.abi.entrys,
        registerAddressInfo.contract_address
    );

    return await contract.isValidUser().call();
}

const getExtension = async () => {

    while (!KHCExtension || !KHCExtension.defaultAddress.base58) {
        KHCExtension = window.KHCExtension;
        await new Promise((resolve) => {
            setTimeout(() => {
                resolve();
            }, 10);
        });
    }
    return KHCExtension;
};

// const get20Contract = async (contractAddress) => {
//     if (Contract) return;
//     try {
//         // Contract = await KHCExtension.contract().at(contractAddress)
//         Contract = await KHCExtension.contract(msdtContractInfo.abi.entrys, contractAddress);
//     } catch (err) {
//         await getContract()
//     }
// };

export async function get20Contract(contractAddress){
    // try {
    //     let contract = await KHCExtension.contract(msdtContractInfo.abi.entrys, contractAddress);
    //     callback(contract)
    // } catch (err) {
    //     console.log(err)
    //     await get20Contract(contractAddress, callback)
    // }

    return await KHCExtension.contract(msdtContractInfo.abi.entrys, contractAddress);
}

export async function getPurchaseContract() {
    return await KHCExtension.contract(purchaseContractInfo.abi.entrys, purchaseContract);
}

export async function getUSDTContract() {
    return await KHCExtension.contract(msdtContractInfo.abi.entrys, msdtContract);
}

export async function getICSContract() {
    return await KHCExtension.contract(msdtContractInfo.abi.entrys, icsContract);
}

export async function getCNCContract() {
    return await KHCExtension.contract(msdtContractInfo.abi.entrys, cncContract);
}

export async function getMiningContract() {
    return await KHCExtension.contract(miningContractInfo.abi.entrys, miningContractAddress);
}

export async function getResonanceContract() {
    return await KHCExtension.contract(resonanceContractInfo.abi.entrys, resonanceContractAddress);
}

export function checkAddress() {
    if (!KHCExtension) {
        return { success: false, message: '请先安装 KHCExtension 插件' }
    } else if (!KHCExtension.defaultAddress) {
        return { success: false, message: '请先创建钱包或者解锁插件' }
    } else {
        return { success: true, address: KHCExtension.defaultAddress.base58 }
    }
}

export async function signTimestamp() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    const params = {
        timestamp:timestamp,
        address: KHCExtension.defaultAddress.base58,
        signature:signature
    };

    try {
        params.sign = await KHCExtension.trx.sign(signature);

        return params;
    } catch (e) {
        console.warn(e);
        return false;
    }
}

export function signSimulate() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    return {
        timestamp: timestamp,
        address: KHCExtension.defaultAddress.base58,
        sign: signature
    };
}

export async function getBalance() {
    const result = await KHCExtension.trx.getUnconfirmedAccount(KHCExtension.defaultAddress.base58);
    let balance = Number(KHCExtension.fromSun(result.balance));
    balance = (Math.floor(balance * 10000) / 10000).toFixed(4)
    return Number(balance)
}

export async function get20Balance() {
    const result = await KHCExtension.contract().at(msdtContract);
    return result.balanceOf(KHCExtension.defaultAddress.base58).call()
}

export async function get20BalanceResult() {
    let result = await KHCExtension.contract(msdtContractInfo.abi.entrys, msdtContractInfo.contract_address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromSun(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)
    return balance_20
}

export async function getICSBalanceResult() {
    let result = await KHCExtension.contract(msdtContractInfo.abi.entrys, KHCExtension.address.toHex(icsContract));
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromSun(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)
    return balance_20
}

export async function getCNCBalanceResult() {
    let result = await KHCExtension.contract(msdtContractInfo.abi.entrys, KHCExtension.address.toHex(cncContract));
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromSun(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20);
    return balance_20
}

export async function getFee(){
    let result = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
    let  fee = await result.cancelFee().call();
    fee = KHCExtension.toDecimal(fee);
    return KHCExtension.fromSun(fee);
}

export async function transfer(amount) {
    return KHCExtension.trx.sendTransaction(contractAddress, KHCExtension.toSun(amount));
}

export async function makeOrder(symbol1, symbol2, amount, price, min, max) {  // symbol1 给钱的币种 symbol2 要买的币种id
    if (!Contract) return false;

    return Contract.makeOrder(symbol1, symbol2, amount, amount, min, max).send();
}

export async function takeOrder(orderId, symbolId, amount) { // symbol 给钱的币种
    if (!Contract) return false;

    return Contract.takeOrder(orderId, symbolId, amount).send();
}

export async function cancelOrder(orderId) {
    if (!Contract) return false;
    return Contract.cancelOrder(orderId).send();
}


