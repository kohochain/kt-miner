const JsSHA = require('jssha/src/sha256');
const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const ALPHABET_MAP = {};
for (let i = 0; i < ALPHABET.length; ++i) {
    ALPHABET_MAP[ALPHABET.charAt(i)] = i;
}
const BASE = ALPHABET.length;

function decode(string) {
    if (string.length === 0) return [];

    let i; let j; const
        bytes = [0];
    for (i = 0; i < string.length; ++i) {
        const c = string[i];
        if (!(c in ALPHABET_MAP)) throw new Error('Non-base58 character');

        for (j = 0; j < bytes.length; ++j) bytes[j] *= BASE;
        bytes[0] += ALPHABET_MAP[c];

        let carry = 0;
        for (j = 0; j < bytes.length; ++j) {
            bytes[j] += carry;
            carry = bytes[j] >> 8;
            bytes[j] &= 0xff;
        }

        while (carry) {
            bytes.push(carry & 0xff);
            carry >>= 8;
        }
    }
    // deal with leading zeros
    for (i = 0; string[i] === '1' && i < string.length - 1; ++i) {
        bytes.push(0);
    }

    return bytes.reverse();
}

function sha256(hexString) {
    const sha = new JsSHA('SHA-256', 'HEX');
    sha.update(hexString);
    return sha.getHash('HEX');
}

/* Convert a byte to string */
function byte2hexStr(byte) {
    const hexByteMap = '0123456789ABCDEF';
    let str = '';
    str += hexByteMap.charAt(byte >> 4);
    str += hexByteMap.charAt(byte & 0x0f);
    return str;
}

// byteArray格式数据转为16进制的ASCII字符串。
function byteArray2hexStr(byteArray) {
    let str = '';
    for (let i = 0; i < byteArray.length; i++) {
        str += byte2hexStr(byteArray[i]);
    }
    return str;
}

/* Check if a char is hex char */
function isHexChar(c) {
    if ((c >= 'A' && c <= 'F')
        || (c >= 'a' && c <= 'f')
        || (c >= '0' && c <= '9')) {
        return 1;
    }
    return 0;
}

/* Convert a hex char to value */
function hexChar2byte(c) {
    let d = 0;
    if (c >= 'A' && c <= 'F') {
        d = c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
    } else if (c >= 'a' && c <= 'f') {
        d = c.charCodeAt(0) - 'a'.charCodeAt(0) + 10;
    } else if (c >= '0' && c <= '9') {
        d = c.charCodeAt(0) - '0'.charCodeAt(0);
    }
    return d;
}

function hexStr2byteArray(str) {
    const byteArray = Array();
    let d = 0;
    let i = 0;
    let j = 0;
    let k = 0;

    for (i = 0; i < str.length; i++) {
        const c = str.charAt(i);
        if (isHexChar(c)) {
            d <<= 4;
            d += hexChar2byte(c);
            j++;
            if ((j % 2) === 0) {
                byteArray[k++] = d;
                d = 0;
            }
        }
    }
    return byteArray;
}

function decodeBase58Address(base58Sting) {
    if (typeof (base58Sting) !== 'string') {
        return false;
    }
    if (base58Sting.length <= 4) {
        return false;
    }
    let address;
    try {
        address = decode(base58Sting);
    } catch (e) {
        return false;
    }
    if (base58Sting.length <= 4) {
        return false;
    }
    const len = address.length;
    const offset = len - 4;
    const checkSum = address.slice(offset);
    address = address.slice(0, offset);
    const hash0 = sha256(byteArray2hexStr(address));
    const hash1 = hexStr2byteArray(sha256(hash0));
    const checkSum1 = hash1.slice(0, 4);
    if (checkSum[0] === checkSum1[0] && checkSum[1] === checkSum1[1] && checkSum[2]
        === checkSum1[2] && checkSum[3] === checkSum1[3]
    ) {
        return address;
    }

    return false;
}

export default function (mainAddress) {
    const address = decodeBase58Address(mainAddress);

    if (!address) {
        return false;
    }

    if (address.length !== 21) {
        return false;
    }

    return address[0] === 0x32;
}
