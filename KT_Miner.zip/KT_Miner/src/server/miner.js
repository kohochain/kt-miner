import { get, post } from './method';

const pre = '/mine';

export default {
    // 地址信息
    getMinerAddressInfo: (data) => get(`${pre}/addressInfo`, data),

    // 优先认购权
    getMinerBurnPipeline: (data) => get(`${pre}/burnPipeline`, data),

    // 全球信息
    getMinerGlobalInfo: (data) => get(`${pre}/globalInfo`, data),

    // 共享算力
    getMinerShareGuarantee: (data) => get(`${pre}/shareGuarantee`, data),

    // 团队信息
    getMinerGroupInfo: (data) => get(`${pre}/groupInfo`, data),

    // 算力流水
    getMinerGuaranteePipelineKht: (data) => get(`${pre}/guaranteePipelineKht`, data),

    // KHT算力流水
    getMinerGuaranteePipeline: (data) => get(`${pre}/guaranteePipeline`, data),

    // 收益流水
    getMinerRewardPipeline: (data) => get(`${pre}/rewardPipeline`, data),

    // address active
    getAuthAddressActive: data => get(`/auth/access/address/invite_code`, data),

    /**
     * 地址信息
     *
     */
    getPurchaseCheckInviteCode: (data) => get(`/purchase/checkInviteCode`, data),

    /**
     * 修改倍率
     *
     */
    postMinerKHTRate: (data) => post(`${pre}/setKhtRate`, data),

    /**
     * 埋点
     *
     */
    getMineClick: (data) => get(`${pre}/click`, data),

    /**
     * 续押
     *
     */
    postMineFreeze: (data) => post(`${pre}/freeze`, data),
}
