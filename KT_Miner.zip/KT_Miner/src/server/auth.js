import { get, post } from './method';

const pre = '/auth';

export default {
	// 地址登录
	authPostLogin: data => post(`${pre}/access/address/login`, data),

	// 获取用户信息
	authGetUserInfo: () => get(`${pre}/login_info`),

	// 检查验证码是否有效
	authCheckInvite: inviteCode => get(`${pre}/access/invite_code`, { inviteCode }),

	// 查询下级数据
	groupInviteAddress: () => get('/group/inviteAddress'),

	// address active
	getAuthAddressActive: data => get(`${pre}/access/address/invite_code`, data)
}