import { get, post} from './method';

const request = {
    //---------------------------------------Purchase Controller---------------------------------------


    /**
     * 共振进度
     *
     */
    getPurchaseAddressInfo: (data) => get(`/cncPurchase/purchaseInfo`, data),

    /**
     * 共振池进度
     *
     */
    getPurchasePool: (data) => get(`/cncPurchase/purchasePool`, data),

    /**
     * 共振余额
     *
     */
    postPurchaseBalance: (data) => get(`/cncPurchase/purchaseBalance`, data),

    /**
     * 共振
     *
     */
    postPurchase: (data) => post(`/cncPurchase/purchase`, data),

    /**
     * 共振记录
     *
     */
    postPurchaseHistory: (data) => get(`/cncPurchase/purchaseHistory`, data),

    /**
     * 计算共振数量
     *
     */
    getPurchaseQuantity: (data) => get(`/cncPurchase/getPrice`, data),

    /**
     * 共振结果
     *
     */
    getPurchaseResult: (data) => get(`/cncPurchase/getPurchasePipeline`, data),

    /**
     * 充值记录
     *
     */
    getDepositHistory: (data) => get(`/cncPurchase/depositHistory`, data),

    /**
     * 提现记录
     *
     */
    getWithdrawHistory: (data) => get(`/cncPurchase/withdrawHistory`, data),

    /**
     * 联动额度
     *
     */
    getPurchaseQuota: (data) => get(`/cncPurchase/purchaseQuota`, data),

    /**
     * 直推用户信息
     *
     */
    getPurchaseMember: (data) => get(`/cncPurchase/purchaseMember`, data),

    //postPurchaseBalance
}

export default request;
