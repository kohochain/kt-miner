import { get, post } from './method';
import purchase from './purchase';
import auth from './auth';
import swap from './swap';
import miner from "./miner";

const request = {
    // 登录
    login: data => post('/auth/access/address/login', data),

    // 登出
    logout: () => get('/auth/logout'),

    // 登录
    userInfo: () => get('/auth/login_info'),

    //查询订单列表
    getOrderList: (data) => get(`/trade/orderList`, data),

    //查询订单历史
    getOrderHistory: (data) => get(`/trade/orderHistory`, data),

    //买单查询订单状态
    getOrderStatus: (data) => get(`/trade/takeOrderStatus`, data),

    //买单查询订单结果
    getOrderResult: (data) => get(`/trade/tickDetail`, data),

    //查订单详情
    getOrderDetail: (data) => get(`/trade/orderDetail`, data),

    //查委托单子订单
    getOrderTicks: (data) => get(`/trade/orderTicks`, data),

    //领取空投
    postAirdrop: (data) => post(`/purchase/airdrop`, data),

    //查询币种详情
    getCoinList: () => get(`/trade/tradeSymbolList`),

        //查询订单挂单数量
    getOrderCount: (data) => get(`/trade/orderCount`, data),

    // 挖矿算力流水
    // getMinerGuaranteePipeline: (page, pageSize, address) => get(`/mine/guaranteePipeline?page=${page}&pageSize=${pageSize}&address=${address}`),

    // 挖矿收益流水
    // getMinerRewardPipeline: (page, pageSize, address) => get(`/mine/rewardPipeline?page=${page}&pageSize=${pageSize}&address=${address}`),

    // 交易参数
    getTradeTradeConfig: () => get('/trade/tradeConfig'),

    ...purchase,
    ...auth,
    ...swap,
    ...miner,
};

export default request;
