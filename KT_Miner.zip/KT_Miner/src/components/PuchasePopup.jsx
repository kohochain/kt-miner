import React, { Component } from "react";
import { Modal } from 'antd-mobile';
import {mathFloor} from '../lib/number';


class PurchasePopup extends Component {

    render() {
        const { 
                visible,
                onClose,
                onChange,
                onConfirm,
                balance,
                purchaseInfo,
                purchaseAmount
            } = this.props;

        return (
            <Modal
                visible={visible}
                onClose={onClose}
                popup
                animationType="slide-up"
            >
                <div className={'pop'}>
                    <div className={'flex-start p-l-5 p-r-5'}>
                        <div className={'pop-cancel'} onClick={onClose}>取消</div>
                        <div className={'pop-title text-center'}>认购确认</div>
                    </div>
                    <div className={'pop-line m-t-4'}></div>
                    <div className={'p-l-5 p-r-5'}>
                        <div className={'flex-between m-t-8'}>
                            <div className={'pop-content'}>本期认购个人剩余额度</div>
                            <div className={'pop-content'}>{mathFloor(purchaseInfo.userLimit - purchaseInfo.totalSubscribe, 4)} ICS</div>
                        </div>
                        <div className={'flex-between m-t-3'}>
                            <div className={'pop-content'}>本期认购单价</div>
                            <div className={'pop-content'}>{purchaseInfo.price} USDT</div>
                        </div>
                        <div className={'flex-between  m-t-3'}>
                            <div className={'pop-content'}>当前地址余额</div>
                            <div className={'pop-content'}>{balance['mdc']} MDC</div>
                        </div>
                        <div className={'flex-between  m-t-1'}>
                            <div className={'pop-content'}></div>
                            <div className={'pop-content'}>{balance['usdt']} USDT</div>
                        </div>
                        <div className={'pop-title text-left m-t-3 m-b-3'}>您想要认购的数量</div>
                        <div className={'relative'}>
                            <input
                                className={'pop-input'}
                                placeholder="请输入认购数量"
                                type="text"
                                onChange={(value) => onChange(value.target.value)} 
                                value={purchaseAmount}
                            />
                            <div className={'pop-prefix'}>ICS</div>
                        </div>
                        <div className={'flex-end m-t-1'}>≈ {(purchaseAmount * purchaseInfo.price).toFixed(8)} USDT</div>
                        <div className={'pop-btn m-t-8'} onClick={onConfirm}>确认</div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default PurchasePopup;
