import {combineReducers} from 'redux';
import * as actionsTypes from './actionsTypes';

const data = {
    address: '',
    balance: {
        mdc: 0,
        xcn:0,
        ics:0,
        usdt: 0,
        fee: 0.01,
        cnc:0,
    },
    deviceId: '',
    fee: {
        usdt: {buy: 0.003, sell: 0.003},
        mdc: {buy: 0.003, sell: 0.003},
    },
    tokenList:[],
    account:{
        share:[],
        bonus:[],
        contractFee:[],
    },
    active: 0,
    tab: 'purchase',
    balances:[],
};

const reducer = {
    redux: (state = data, action) => {
        switch (action.type) {
            case actionsTypes.SET_ADDRESS:
                return {...state, address: action.data};
            case actionsTypes.UPDATE_BALANCE:
                return {...state, balance: action.data};
            case actionsTypes.SET_DEVICE:
                return {...state, deviceId: action.data};
            case actionsTypes.SET_FEE:
                return {...state, fee: action.data};
            case actionsTypes.SET_ACTIVE:
                return {...state, active: action.data}
            case actionsTypes.TAB:
                return {...state, tab: action.data};
            case actionsTypes.SET_TOKENLIST:
                return {...state, tokenList: action.data};
            case actionsTypes.SET_ACCOUNT:
                return {...state, account: action.data};
            case actionsTypes.SET_BALANCE:
                return {...state, balances:action.data};
            default:
                return state;
        }
    },
};

export default combineReducers(reducer);
